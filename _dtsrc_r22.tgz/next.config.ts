import type { NextConfig } from 'next'
import createNextIntlPlugin from 'next-intl/plugin'

const withNextIntl = createNextIntlPlugin('./src/i18n/request.ts')

const nextConfig: NextConfig = {
  images: {
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    // Next 16 refuses any `quality` prop not declared here.
    // 75 = next/image default; 82 = hero sliders (HomeShowcase, BrandSections).
    qualities: [75, 82],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 60 * 60 * 24 * 30, // 30 days
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'pub-*.r2.dev',
      },
    ],
    // SmartImage falls back to local SVG placeholders under
    // /public/images/placeholders. next/image refuses SVGs by default;
    // these are trusted (we wrote them) and the CSP keeps scripts out.
    dangerouslyAllowSVG: true,
    contentDispositionType: 'attachment',
    contentSecurityPolicy:
      "default-src 'self'; script-src 'none'; sandbox;",
  },

  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-DNS-Prefetch-Control', value: 'on' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
      {
        source: '/images/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
      {
        source: '/fonts/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
    ]
  },

  experimental: {
    serverActions: {
      bodySizeLimit: '25mb',
    },
    /**
     * Client router cache: keep visited dynamic pages fresh-enough for 30 s
     * so back/forward and revisits render instantly instead of refetching.
     * Server actions still purge this via revalidatePath after mutations.
     */
    staleTimes: {
      dynamic: 30,
      static: 180,
    },
  },

  compress: true,
  reactStrictMode: true,
  poweredByHeader: false,
}

export default withNextIntl(nextConfig)
