'use client'

/**
 * ROUND 19 G — /gaming, "violet / verre".
 *
 * Fourth pass, and the first one Ghani chose himself: after three rejected
 * designs he picked this direction from four side-by-side options. The
 * rejected ones are worth naming so nobody rebuilds them — hover-only RGB
 * (no lights at rest), ambient RGB around a CSS-DRAWN PC CASE (read as
 * fake — never draw hardware on a site that sells the real thing), and a
 * lime/angular esports look (rejected outright).
 *
 * The system: deep violet-black ground, animated halos, frosted glass,
 * ONE violet→cyan gradient for every accent, generous radii, and real
 * product photography sitting on a soft light pool.
 *
 * Client component only for the tab state. Everything else is server data
 * + CSS; no scroll listener, no rAF. See the CSS block for the
 * backdrop-filter budget, which matters on mid-range Android.
 */

import { useState } from 'react'
import Image from 'next/image'
import { Link } from '@/i18n/routing'
import { useEditorial } from './editorial-context'
import { EIcon } from './editorial-icons'
import { BrandMarkArt } from '@/components/home/brand-marks'
import { WA } from './EditorialChrome'
import type { EdGamingData } from '@/server/gaming-data'

export function EdGamingPage({ data }: { data: EdGamingData }) {
  const { t, tf } = useEditorial()
  const [col, setCol] = useState(data.collections[0]?.id ?? 'build')
  const active = data.collections.find((c) => c.id === col) ?? data.collections[0]

  /** The single product that fronts the page — first featured item with art. */
  const hero = data.showcase[0] ?? null

  /** ARIA APG tabs keyboard model: arrows move, Home/End jump, focus follows. */
  const onTabKey = (e: React.KeyboardEvent<HTMLButtonElement>, i: number) => {
    const n = data.collections.length
    if (n < 2) return
    let next = -1
    if (e.key === 'ArrowRight') next = (i + 1) % n
    else if (e.key === 'ArrowLeft') next = (i - 1 + n) % n
    else if (e.key === 'Home') next = 0
    else if (e.key === 'End') next = n - 1
    else return
    e.preventDefault()
    const target = data.collections[next]
    if (!target) return
    setCol(target.id)
    document.getElementById(`edg-tab-${target.id}`)?.focus()
  }

  return (
    <div className="edg">
      {/* Ambient halos — four blurred blobs on long offset periods, so the
          light never visibly loops. They sit behind everything. */}
      <span className="edg-aur" aria-hidden>
        <i />
        <i />
        <i />
        <i />
      </span>

      {/* ── Hero ── */}
      <header className="edg-hero" data-band="dark">
        <div className="wrap edg-heroin">
          <div className="edg-herotext">
            <span className="edg-pill">
              <em />
              {t('gm.eyebrow')} · Alger
            </span>
            <h1 className="edg-h1">
              {t('gm.t1')}{' '}
              <span className="edg-grad">
                {t('gm.t2')} {t('gm.t3')}
              </span>
            </h1>
            <p className="edg-hsub">{t('gm.lede')}</p>
            <div className="edg-hbtns">
              <a className="edg-btn" href="#config">
                {t('gm.cta1')}
                <EIcon n="chevR" s={14} sw={2.6} />
              </a>
              <a className="edg-btn o" href={WA} target="_blank" rel="noopener noreferrer">
                {t('gm.cta2')}
              </a>
            </div>
            <div className="edg-stats">
              <div className="edg-stat">
                <b>{data.total}</b>
                <i>{t('gm.s1')}</i>
              </div>
              <div className="edg-stat">
                <b>{data.brands.length}</b>
                <i>{t('gm.s2')}</i>
              </div>
              <div className="edg-stat">
                <b>{data.steps.length}</b>
                <i>{t('gm.s3')}</i>
              </div>
              <div className="edg-stat">
                <b>58</b>
                <i>{t('bp.st3')}</i>
              </div>
            </div>
          </div>

          {/* A real product photo on a glass panel — NOT a CSS drawing. */}
          {hero ? (
            <div className="edg-hpanel">
              <span className="edg-pill edg-hchip">{t('gm.stock')}</span>
              <span className="edg-pool" aria-hidden />
              <span className="edg-hshot">
                {hero.img ? (
                  <Image
                    src={hero.img}
                    alt={hero.name}
                    fill
                    sizes="(max-width: 940px) 88vw, 460px"
                    style={{ objectFit: 'contain' }}
                    priority
                  />
                ) : null}
              </span>
            </div>
          ) : null}
        </div>
      </header>

      {/* ── Brand ticker ── */}
      {data.brands.length > 0 ? (
        <section className="edg-sec" data-band="dark" style={{ paddingTop: 6 }}>
          <div className="wrap">
            <div className="edg-marq">
              {/* Duplicated once so the -50% translate loops seamlessly. */}
              <div className="edg-marqrow">
                {[...data.brands, ...data.brands].map((b, i) => (
                  <Link className="edg-bchip" key={`${b.slug}-${i}`} href={`/brands/${b.slug}`}>
                    <span className="edg-bmark">
                      <BrandMarkArt slug={b.slug} name={b.name} h={22} maxW={96} />
                    </span>
                    <i>{b.count}</i>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      ) : null}

      {/* ── Build path ── */}
      {data.steps.length > 0 ? (
        <section className="edg-sec" id="config" data-band="dark">
          <div className="wrap">
            <div className="edg-shead rv">
              <div>
                <span className="edg-pill">{t('gm.build')}</span>
                <h2>{t('gm.buildTitle')}</h2>
              </div>
              <p>{t('gm.buildLede')}</p>
            </div>
            <ol className="edg-steps rv">
              {data.steps.map((s, i) => (
                <li key={s.slug} className="stag" style={{ ['--i' as string]: String(i) }}>
                  <Link
                    href={{ pathname: '/products', query: { category: s.slug } }}
                    className="edg-step"
                  >
                    <span className="edg-stepn">{String(i + 1).padStart(2, '0')}</span>
                    <span className="edg-stepbody">
                      <b>{t(`gm.step.${s.slug}`)}</b>
                      <i>
                        {s.count} {t('bi.refs')}
                      </i>
                    </span>
                    <span className="edg-stepgo" aria-hidden>
                      →
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
          </div>
        </section>
      ) : null}

      {/* ── The three gaming catalogues ── */}
      {active ? (
        <section className="edg-sec" data-band="dark">
          <div className="wrap">
            <div className="edg-shead rv">
              <div>
                <span className="edg-pill">{t('gm.cat')}</span>
                <h2>{t('gm.catTitle')}</h2>
              </div>
              <p>{t('gm.catLede')}</p>
            </div>

            <div className="edg-tabs rv" role="tablist" aria-label={t('gm.cat')}>
              {data.collections.map((c, i) => (
                <button
                  key={c.id}
                  role="tab"
                  type="button"
                  id={`edg-tab-${c.id}`}
                  aria-selected={c.id === col}
                  aria-controls={`edg-panel-${c.id}`}
                  tabIndex={c.id === col ? 0 : -1}
                  className={c.id === col ? 'on' : undefined}
                  onClick={() => setCol(c.id)}
                  onKeyDown={(e) => onTabKey(e, i)}
                >
                  {t(`gm.col.${c.id}`)}
                  <em>{c.products.length}</em>
                </button>
              ))}
            </div>

            <p className="edg-colnote rv">{t(`gm.col.${active.id}.d`)}</p>

            {/* Every panel renders; inactive ones are `hidden`, so the
                aria-controls on each tab always points at a real node. */}
            {data.collections.map((c) => (
              <div
                key={c.id}
                className="edg-grid2 rv"
                role="tabpanel"
                id={`edg-panel-${c.id}`}
                aria-labelledby={`edg-tab-${c.id}`}
                hidden={c.id !== col}
              >
                {c.products.map((p, i) => (
                  <Link
                    className="edg-card stag"
                    key={p.slug}
                    href={`/products/${p.slug}`}
                    style={{ ['--i' as string]: String(i % 8) }}
                  >
                    <span className="edg-stage">
                      <span className={`edg-ctag${p.featured ? ' hot' : ''}`}>
                        {p.featured ? t('gm.top') : p.catName}
                      </span>
                      {p.img ? (
                        <Image
                          src={p.img}
                          alt=""
                          fill
                          sizes="(max-width: 720px) 46vw, 264px"
                          style={{ objectFit: 'contain' }}
                        />
                      ) : null}
                    </span>
                    <span className="edg-cardbody">
                      <i>
                        {p.brand} · {p.catName}
                      </i>
                      <b>{p.name}</b>
                      <span className="edg-cfoot">
                        <span>{t('gm.stock')}</span>
                        <em>{t('gm.see')} →</em>
                      </span>
                    </span>
                  </Link>
                ))}
              </div>
            ))}

            <div className="edg-all rv">
              <Link
                className="edg-btn"
                href={{ pathname: '/products', query: { category: 'gaming' } }}
              >
                {tf('gm.all', { count: data.gearCount })}
                <EIcon n="chevR" s={14} sw={2.6} />
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* ── CTA ── */}
      <section className="edg-cta" data-band="dark">
        <div className="wrap">
          <div className="edg-ctain">
            <div>
              <h2>{t('gm.ctaTitle')}</h2>
              <p>{t('gm.ctaLede')}</p>
            </div>
            <div className="edg-ctabtns">
              <Link className="edg-btn" href="/contact">
                {t('gm.ctaBtn')}
              </Link>
              <a className="edg-btn o" href={WA} target="_blank" rel="noopener noreferrer">
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
