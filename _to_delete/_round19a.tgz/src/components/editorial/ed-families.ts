/**
 * ROUND 19 — the seven commercial universes the 20 catalogue categories roll
 * up into. One source of truth shared by the Catalogue mega-menu (client),
 * the /catalogue page (client) and the Gaming page's parts rail, so the
 * grouping can never drift between surfaces.
 *
 * NOT a client module on purpose: server components import GAMING_SLUGS to
 * pre-filter data. Keep it free of React and of `server-only`.
 *
 * `slugs` is ordered — it drives display order inside a family. Any category
 * slug that is NOT listed here still renders, collected into a trailing
 * "other" family, so adding a category in the admin can never make it vanish
 * from the catalogue page.
 */

export interface EdFamily {
  /** i18n key suffix: `fam.<id>` for the label, `fam.<id>.d` for the blurb. */
  id: string
  slugs: string[]
  /** Accent hue used for the family's tile gradient + rules. */
  hue: number
  icon: EdFamilyIcon
}

export type EdFamilyIcon =
  | 'work'
  | 'display'
  | 'print'
  | 'build'
  | 'net'
  | 'power'
  | 'play'
  | 'other'

export const ED_FAMILIES: EdFamily[] = [
  { id: 'work', hue: 188, icon: 'work', slugs: ['laptops', 'desktops', 'all-in-one', 'tablets'] },
  { id: 'display', hue: 262, icon: 'display', slugs: ['monitors', 'projectors'] },
  { id: 'print', hue: 24, icon: 'print', slugs: ['printers', 'scanners', 'consumables'] },
  {
    id: 'build',
    hue: 330,
    icon: 'build',
    slugs: [
      'motherboards',
      'processors',
      'graphics-cards',
      'storage',
      'pc-cases',
      'cooling',
      'power-supplies',
    ],
  },
  { id: 'net', hue: 158, icon: 'net', slugs: ['networking'] },
  { id: 'power', hue: 42, icon: 'power', slugs: ['ups', 'power-banks'] },
  { id: 'play', hue: 286, icon: 'play', slugs: ['gaming'] },
]

/**
 * Everything the Gaming page treats as gaming: the gaming category itself,
 * plus the build-parts families a rig is assembled from, plus displays.
 * (Brand-level gaming filtering — GameMax, Game Revolution, ROG/TUF, MPG —
 * happens on top of this in the page itself.)
 */
export const GAMING_SLUGS = [
  'gaming',
  'graphics-cards',
  'processors',
  'motherboards',
  'pc-cases',
  'cooling',
  'power-supplies',
  'storage',
  'monitors',
] as const

/** Brands whose entire range is gaming-oriented. */
export const GAMING_BRANDS = ['gamemax', 'game-revolution', 'msi', 'reaction'] as const

/** Name fragments that mark a gaming SKU inside a non-gaming brand. */
export const GAMING_NAME_HINTS = [
  'rog',
  'tuf',
  'mpg',
  'gaming',
  'gamer',
  'radeon',
  'geforce',
  'rtx',
  'gtx',
] as const

/** Family a category slug belongs to, or null when it is unclassified. */
export function familyOf(slug: string): EdFamily | null {
  return ED_FAMILIES.find((f) => f.slugs.includes(slug)) ?? null
}

/**
 * Bucket a category list into families, preserving the declared slug order
 * inside each family and appending an `other` family for anything unmapped.
 * Families with no matching category are dropped.
 */
export function groupByFamily<T extends { slug: string }>(
  cats: T[]
): { family: EdFamily; cats: T[] }[] {
  const bySlug = new Map(cats.map((c) => [c.slug, c]))
  const claimed = new Set<string>()
  const out: { family: EdFamily; cats: T[] }[] = []

  for (const family of ED_FAMILIES) {
    const picked: T[] = []
    for (const slug of family.slugs) {
      const c = bySlug.get(slug)
      if (c) {
        picked.push(c)
        claimed.add(slug)
      }
    }
    if (picked.length) out.push({ family, cats: picked })
  }

  const rest = cats.filter((c) => !claimed.has(c.slug))
  if (rest.length) {
    out.push({
      family: { id: 'other', hue: 210, icon: 'other', slugs: rest.map((c) => c.slug) },
      cats: rest,
    })
  }
  return out
}
