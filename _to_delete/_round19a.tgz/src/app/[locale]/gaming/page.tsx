import { redirect } from 'next/navigation'
import { setRequestLocale } from 'next-intl/server'

/**
 * ROUND 19 (phase A) — placeholder so the new nav never 404s.
 *
 * The real Gaming page (dark neon skin, gaming brands, build-parts rails,
 * gaming catalogues) lands in phase C and REPLACES this file wholesale. Until
 * then the nav entry resolves to the gaming slice of the catalogue, which is
 * the closest honest destination.
 */
export const dynamic = 'force-dynamic'

export default async function GamingPage({
  params,
}: {
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)
  redirect(`/${locale}/products?category=gaming`)
}
