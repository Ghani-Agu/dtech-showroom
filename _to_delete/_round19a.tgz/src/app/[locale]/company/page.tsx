import { redirect } from 'next/navigation'
import { setRequestLocale } from 'next-intl/server'

/**
 * ROUND 19 (phase A) — placeholder so the new nav never 404s.
 *
 * The real Company page (Hartech since 2006, own brands D-tech + InkMaster,
 * achievements, distribution partners, client logos) lands in phase C and
 * REPLACES this file wholesale.
 */
export const dynamic = 'force-dynamic'

export default async function CompanyPage({
  params,
}: {
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)
  redirect(`/${locale}/about`)
}
