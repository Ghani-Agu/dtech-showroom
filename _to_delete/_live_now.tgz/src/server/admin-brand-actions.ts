'use server'

import { revalidatePath } from 'next/cache'
import { revalidateStorefront } from '@/lib/revalidate'
import { count, eq } from 'drizzle-orm'
import { db } from '@/db/client'
import { brands, products } from '@/db/schema'
import { requireSection } from '@/lib/auth-helpers'
import {
  brandFormSchema,
  type BrandFormValues,
} from '@/lib/validations/brand'

function normalize(values: BrandFormValues) {
  return {
    ...values,
    nameFr: values.nameFr || null,
    statementFr: values.statementFr || null,
    descriptionFr: values.descriptionFr || null,
    searchKeywords: values.searchKeywords || null,
    searchKeywordsFr: values.searchKeywordsFr || null,
    logoPath: values.logoPath || null,
    heroImagePath: values.heroImagePath || null,
  }
}

export async function createBrand(values: BrandFormValues) {
  await requireSection('brands')

  const parsed = brandFormSchema.safeParse(values)
  if (!parsed.success) {
    return {
      ok: false as const,
      errors: parsed.error.flatten().fieldErrors,
    }
  }

  const existing = await db
    .select({ id: brands.id })
    .from(brands)
    .where(eq(brands.slug, parsed.data.slug))
    .limit(1)
    .then((rows) => rows[0])

  if (existing) {
    return {
      ok: false as const,
      errors: { slug: ['A brand with this slug already exists'] },
    }
  }

  const inserted = await db
    .insert(brands)
    .values(normalize(parsed.data))
    .returning({ id: brands.id })

  revalidateStorefront()
  revalidatePath('/admin/brands')
  revalidatePath('/brands')
  revalidatePath('/')

  const newId = inserted[0]?.id
  if (!newId) {
    return { ok: false as const, errors: { _form: ['Insert failed'] } }
  }
  return { ok: true as const, id: newId }
}

export async function updateBrand(
  brandId: string,
  values: BrandFormValues
) {
  await requireSection('brands')

  const parsed = brandFormSchema.safeParse(values)
  if (!parsed.success) {
    return {
      ok: false as const,
      errors: parsed.error.flatten().fieldErrors,
    }
  }

  const slugTaken = await db
    .select({ id: brands.id })
    .from(brands)
    .where(eq(brands.slug, parsed.data.slug))
    .limit(1)
    .then((rows) => rows[0])

  if (slugTaken && slugTaken.id !== brandId) {
    return {
      ok: false as const,
      errors: { slug: ['A brand with this slug already exists'] },
    }
  }

  await db
    .update(brands)
    .set({ ...normalize(parsed.data), updatedAt: new Date() })
    .where(eq(brands.id, brandId))

  revalidateStorefront()
  revalidatePath('/admin/brands')
  revalidatePath(`/admin/brands/${brandId}/edit`)
  revalidatePath(`/brands/${parsed.data.slug}`)
  revalidatePath('/brands')
  revalidatePath('/')

  return { ok: true as const, id: brandId }
}

export async function archiveBrand(brandId: string) {
  await requireSection('brands')

  await db
    .update(brands)
    .set({ archivedAt: new Date() })
    .where(eq(brands.id, brandId))

  revalidateStorefront()
  revalidatePath('/admin/brands')
  revalidatePath('/brands')

  return { ok: true as const }
}

export async function restoreBrand(brandId: string) {
  await requireSection('brands')

  await db
    .update(brands)
    .set({ archivedAt: null })
    .where(eq(brands.id, brandId))

  revalidateStorefront()
  revalidatePath('/admin/brands')
  revalidatePath('/brands')

  return { ok: true as const }
}

/**
 * Permanently removes a brand — only allowed when no product uses it,
 * so the catalog can never break.
 */
export async function deleteBrandPermanently(brandId: string) {
  await requireSection('brands')

  const used = await db
    .select({ n: count() })
    .from(products)
    .where(eq(products.brandId, brandId))
    .then((rows) => rows[0]?.n ?? 0)

  if (used > 0) {
    return {
      ok: false as const,
      error: `Impossible de supprimer : ${used} produit(s) utilisent cette marque. Déplacez-les ou supprimez-les d'abord.`,
    }
  }

  await db.delete(brands).where(eq(brands.id, brandId))

  revalidateStorefront()
  revalidatePath('/admin/brands')
  revalidatePath('/brands')
  revalidatePath('/')

  return { ok: true as const }
}
