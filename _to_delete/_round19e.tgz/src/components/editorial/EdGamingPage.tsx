'use client'

/**
 * ROUND 19 (phase C) — /gaming.
 *
 * The one page in this skin that deliberately BREAKS the editorial look.
 * Everywhere else the design is white paper, teal and Comfortaa; here it is
 * near-black with a magenta→cyan neon spectrum, mono type and scanline
 * texture. That is the point — a gamer landing from an ad should know in
 * 200 ms that this section is for them.
 *
 * It stays inside `.editorial-root` (so the pill nav, cart and footer still
 * work) but sets `data-band="dark"` on its own sections, which flips the
 * pill to its dark tone through the existing scroll probe — no new chrome
 * logic. All colour lives under `.edg`, so nothing leaks to other routes.
 *
 * Motion budget: two rAF-free CSS animations (the grid drift and the neon
 * sweep) plus the shared reveal observer. No parallax, no scroll listener —
 * the page has to stay smooth on a mid-range Android.
 */

import { useState } from 'react'
import Image from 'next/image'
import { Link } from '@/i18n/routing'
import { useEditorial } from './editorial-context'
import { EIcon } from './editorial-icons'
import { BrandMarkArt, getBrandMark } from '@/components/home/brand-marks'
import { WA } from './EditorialChrome'
import type { EdGamingData } from '@/server/gaming-data'

export function EdGamingPage({ data }: { data: EdGamingData }) {
  const { t, tf } = useEditorial()
  const [col, setCol] = useState(data.collections[0]?.id ?? 'build')
  const active = data.collections.find((c) => c.id === col) ?? data.collections[0]

  /** ARIA APG tabs keyboard model: arrows move, Home/End jump, focus follows. */
  const onTabKey = (e: React.KeyboardEvent<HTMLButtonElement>, i: number) => {
    const n = data.collections.length
    if (n < 2) return
    let next = -1
    if (e.key === 'ArrowRight') next = (i + 1) % n
    else if (e.key === 'ArrowLeft') next = (i - 1 + n) % n
    else if (e.key === 'Home') next = 0
    else if (e.key === 'End') next = n - 1
    else return
    e.preventDefault()
    const target = data.collections[next]
    if (!target) return
    setCol(target.id)
    document.getElementById(`edg-tab-${target.id}`)?.focus()
  }

  return (
    <div className="edg">
      {/* ── Hero ── */}
      <header className="edg-hero" data-band="dark">
        <span className="edg-grid" aria-hidden />
        <span className="edg-aurora" aria-hidden>
          <i />
          <i />
          <i />
        </span>
        <span className="edg-scan" aria-hidden />
        <span className="edg-sweep" aria-hidden />

        <div className="wrap edg-heroin">
          <div className="edg-herotext">
          <span className="edg-kicker">{t('gm.eyebrow')}</span>
          <h1 className="edg-h1">
            <span>{t('gm.t1')}</span>
            <b>{t('gm.t2')}</b>
          </h1>
          <p className="edg-lede">{t('gm.lede')}</p>

          <div className="edg-stats">
            <div>
              <b>{data.total}</b>
              <span>{t('gm.s1')}</span>
            </div>
            <div>
              <b>{data.brands.length}</b>
              <span>{t('gm.s2')}</span>
            </div>
            <div>
              <b>{data.steps.length}</b>
              <span>{t('gm.s3')}</span>
            </div>
          </div>

          <div className="edg-ctas">
            <a className="edg-btn" href="#config">
              {t('gm.cta1')}
              <EIcon n="chevR" s={15} sw={2.4} />
            </a>
            <a className="edg-btn ghost" href={WA} target="_blank" rel="noopener noreferrer">
              {t('gm.cta2')}
            </a>
          </div>

          </div>

          {/* The rig — a CSS-only RGB tower with spinning fans and a lit
              GPU, with real product shots orbiting it. No image asset, no
              JS; it is what fills the half of the hero that used to be
              empty and it is where the "RGB" of the page lives. */}
          <div className="edg-rig" aria-hidden>
            <div className="edg-tower">
              <span className="edg-fans">
                <span />
                <span />
                <span />
              </span>
              <span className="edg-gpu" />
            </div>
            {data.showcase.length > 0 ? (
              <div className="edg-showcase">
                {data.showcase.map((p, i) => (
                  <span className="edg-shot" key={p.slug} style={{ ['--i' as string]: String(i) }}>
                    {p.img ? (
                      <Image src={p.img} alt="" fill sizes="120px" style={{ objectFit: 'contain' }} />
                    ) : null}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </header>

      {/* ── Gaming brands ── */}
      {data.brands.length > 0 ? (
        <section className="edg-sec" data-band="dark">
          <div className="wrap">
            <div className="edg-head rv">
              <span className="edg-kicker">{t('gm.brands')}</span>
              <h2>{t('gm.brandsTitle')}</h2>
            </div>
            <div className="edg-brands rv">
              {data.brands.map((b, i) => {
                const m = getBrandMark(b.slug, b.name)
                return (
                  <Link
                    className="edg-brand rgb-edge stag"
                    key={b.slug}
                    href={`/brands/${b.slug}`}
                    style={{
                      ['--i' as string]: String(i),
                      ['--bc' as string]: m.tile,
                      ['--bfg' as string]: m.fg,
                    }}
                  >
                    <span className="edg-brandmark">
                      <BrandMarkArt slug={b.slug} name={b.name} h={30} maxW={110} />
                    </span>
                    <i>
                      {b.count} {t('bi.refs')}
                    </i>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>
      ) : null}

      {/* ── Build path ── */}
      {data.steps.length > 0 ? (
        <section className="edg-sec edg-config" id="config" data-band="dark">
          <div className="wrap">
            <div className="edg-head rv">
              <span className="edg-kicker">{t('gm.build')}</span>
              <h2>{t('gm.buildTitle')}</h2>
              <p>{t('gm.buildLede')}</p>
            </div>
            <ol className="edg-steps rv">
              {data.steps.map((s, i) => (
                <li key={s.slug} className="stag" style={{ ['--i' as string]: String(i) }}>
                  <Link
                    href={{ pathname: '/products', query: { category: s.slug } }}
                    className="edg-step rgb-edge"
                  >
                    <span className="edg-spine" aria-hidden />
                    <span className="edg-stepn">{String(i + 1).padStart(2, '0')}</span>
                    <span className="edg-stepimg">
                      {s.img ? (
                        <Image src={s.img} alt="" fill sizes="120px" style={{ objectFit: 'cover' }} />
                      ) : null}
                    </span>
                    <span className="edg-stepbody">
                      <b>{t(`gm.step.${s.slug}`)}</b>
                      <i>
                        {s.count} {t('bi.refs')}
                      </i>
                    </span>
                    <span className="edg-stepgo" aria-hidden>
                      →
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
          </div>
        </section>
      ) : null}

      {/* ── The special gaming catalogues ── */}
      {active ? (
        <section className="edg-sec edg-cols" data-band="dark">
          <div className="wrap">
            <div className="edg-head rv">
              <span className="edg-kicker">{t('gm.cat')}</span>
              <h2>{t('gm.catTitle')}</h2>
              <p>{t('gm.catLede')}</p>
            </div>

            {/* Roving tabindex + arrow keys: the ARIA tabs pattern is what AT
                users will try, and without a key handler the widget reads as
                broken even though Tab+Enter works. */}
            <div className="edg-tabs rv" role="tablist" aria-label={t('gm.cat')}>
              {data.collections.map((c, i) => (
                <button
                  key={c.id}
                  role="tab"
                  type="button"
                  id={`edg-tab-${c.id}`}
                  aria-selected={c.id === col}
                  aria-controls={`edg-panel-${c.id}`}
                  tabIndex={c.id === col ? 0 : -1}
                  className={c.id === col ? 'on' : undefined}
                  onClick={() => setCol(c.id)}
                  onKeyDown={(e) => onTabKey(e, i)}
                >
                  {t(`gm.col.${c.id}`)}
                  <em>{c.products.length}</em>
                </button>
              ))}
            </div>

            <p className="edg-colnote rv">{t(`gm.col.${active.id}.d`)}</p>

            {/* Every panel is rendered and the inactive ones are `hidden`.
                Rendering only the active one left `aria-controls` on the other
                two tabs pointing at IDs that did not exist. */}
            {data.collections.map((c) => (
              <div
                key={c.id}
                className="edg-grid2 rv"
                role="tabpanel"
                id={`edg-panel-${c.id}`}
                aria-labelledby={`edg-tab-${c.id}`}
                hidden={c.id !== col}
              >
                {c.products.map((p, i) => (
                  <Link
                    className="edg-card stag"
                    key={p.slug}
                    href={`/products/${p.slug}`}
                    style={{ ['--i' as string]: String(i % 6) }}
                  >
                    <span className="edg-cardimg">
                      <span className="edg-plate">
                        {p.img ? (
                          <Image
                            src={p.img}
                            alt=""
                            fill
                            sizes="(max-width: 640px) 45vw, 240px"
                            style={{ objectFit: 'contain' }}
                          />
                        ) : null}
                      </span>
                    </span>
                    <span className="edg-cardbody">
                      <i>
                        {p.brand} · {p.catName}
                      </i>
                      <b>{p.name}</b>
                    </span>
                  </Link>
                ))}
              </div>
            ))}

            <div className="edg-all rv">
              {/* gearCount, not total: /products has no facet for "gaming"
                  as a whole, so this button can only honestly quote the size
                  of the gaming CATEGORY it actually lands on. */}
              <Link
                className="edg-btn"
                href={{ pathname: '/products', query: { category: 'gaming' } }}
              >
                {tf('gm.all', { count: data.gearCount })}
                <EIcon n="chevR" s={15} sw={2.4} />
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* ── CTA ── */}
      <section className="edg-sec edg-cta" data-band="dark">
        <div className="wrap">
          <div className="edg-ctawrap">
          <div className="edg-ctain">
          <div>
            <h2>{t('gm.ctaTitle')}</h2>
            <p>{t('gm.ctaLede')}</p>
          </div>
          <div className="edg-ctabtns">
            <Link className="edg-btn" href="/contact">
              {t('gm.ctaBtn')}
            </Link>
            <a className="edg-btn ghost" href={WA} target="_blank" rel="noopener noreferrer">
              WhatsApp
            </a>
          </div>
          </div>
          </div>
        </div>
      </section>
    </div>
  )
}
