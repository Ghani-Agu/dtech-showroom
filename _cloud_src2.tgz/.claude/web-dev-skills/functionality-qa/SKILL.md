---
name: functionality-qa
description: Systematic functional testing of a web app — verifying every feature, flow, form, button, and edge case actually works. Use during every review round of a build, and whenever the user says "test everything", "review the functionalities", "check if it works", "find bugs", or before declaring any feature/project complete. Never mark a feature done without running this skill against it.
---

# Functionality QA

Mindset: assume everything is broken until you've proven otherwise. You are not the developer here; you are the adversary.

## Process

### 1. Build the test inventory
From the requirements checklist (PROJECT_STATE.md), list every:
- Route/page → loads without error? correct data? correct auth behavior?
- Interactive element → every button, link, toggle, dropdown, modal does what its label says?
- Form → covered by the form matrix below
- Flow → multi-step journeys traced end-to-end (signup → onboard → core action → result)
- API endpoint / server action → valid input, invalid input, unauthorized caller

### 2. Execute
Prefer real execution over reading code:
- `npm run build` — must pass with zero errors first
- Run dev server; `curl` API routes with valid/invalid/malicious payloads
- **Execute UI flows with Playwright** (preferred over manual tracing): script the actual journey — `page.fill` the signup form, `page.click` submit, assert the redirect URL and success text, screenshot each step to `screenshots/flows/`. One script per core flow; rerun them every round as regression tests:
```js
await page.goto('http://localhost:3000/signup');
await page.fill('[name=email]', 'qa@test.dz'); await page.fill('[name=password]', 'Str0ng!pass');
await page.click('button[type=submit]');
await page.waitForURL('**/dashboard'); // throws = finding
```
- Only when Playwright execution is impossible: trace the code path manually — handler → validation → mutation → revalidation → UI state — and verify each link exists
- Write quick Vitest/Playwright tests for critical logic when the project has test infra; add minimal infra if logic is complex enough to warrant it

### 3. Form testing matrix (every form, every field)
- Empty submit • required-field enforcement • max-length / overflow input
- Wrong types (letters in number fields, malformed email/phone)
- Special characters, emoji, Arabic/RTL text, leading/trailing spaces
- Double-submit (rapid clicks) — is the button disabled while pending?
- Server error during submit — is there a visible error state, is input preserved?
- Success — clear confirmation, correct redirect, data actually persisted (verify in DB/response)

### 4. State & edge cases per data view
- Empty (zero items) • one item • many items (pagination/scroll) • very long strings (truncation/wrap)
- Loading state visible? Error state recoverable (retry)?
- Stale data after mutation — does the list/detail refresh?

### 5. Auth & permissions (if applicable)
- Every protected route accessed logged-out → redirected?
- Every role tested against every restricted action (direct URL access, not just hidden buttons)
- Multi-tenant: user A can NEVER read/modify tenant B data — test by forging IDs in requests
- Session expiry behavior

### 6. Cross-cutting
- Console errors/warnings on every page (zero tolerance for errors)
- Network tab: failed requests, duplicate requests, oversized payloads
- Refresh mid-flow, browser back button, deep-link directly to inner pages
- Mobile viewport: everything reachable and tappable

## Output format
Findings table: `# | Severity (BLOCKING/HIGH/MEDIUM/LOW) | Location (route + file:line) | What happens | What should happen | Repro steps`. Feed it to gap-analysis. No fixes during this pass — record everything first.
