# Web Dev Skills Pack — v4 (17 skills)

Full-cycle web development for Claude Cowork / Claude Code:
plan → user gate → develop → review (7 passes incl. screenshots + benchmark vs top sites) → user gate → fix/redesign → repeat → user sign-off → deploy.

## Skills

### Orchestrator
| Skill | Role |
|---|---|
| `iterative-perfection-loop` | **Master loop.** Drives all other skills, PROJECT_STATE.md tracking, git checkpoints per round, exit criteria |

### Build
| Skill | Role |
|---|---|
| `web-app-architect` | Stack, structure, routes, planning before code |
| `database-design` | Prisma schemas, migrations, indexes, seeding, pgvector |
| `frontend-design-system` | Design tokens, typography, anti-generic rules + audit mode |
| `ui-animations` | Micro-interactions, Framer Motion, 3D/particles, perf rules |
| `content-localization` | Real copy (no lorem ipsum), AR/FR i18n, RTL, Arabic typography |
| `asset-production` | Original SVG illustration, textures, OG images, favicons — real files, never stock/placeholder |
| `api-integrations-webhooks` | Webhooks (Meta etc.), external APIs, queues, idempotency |

### Review (run all every round)
| Skill | Role |
|---|---|
| `visual-self-review` | Playwright screenshots of every route at 3 viewports — Claude critiques the RENDERED site, not the code |
| `functionality-qa` | Adversarial feature/flow/edge-case testing |
| `code-quality-review` | Security, correctness, performance, maintainability |
| `ux-design-review` | Flows, mobile, WCAG accessibility, RTL |
| `seo-performance-optimization` | Meta/OG, Core Web Vitals, Lighthouse, bundle weight |
| `design-benchmarking` | Screenshot live top-tier reference sites, compare side-by-side, extract specific fixes |
| `gap-analysis` | Merge findings, FIX/REDESIGN/DEFER decisions, next-round plan |

### Support
| Skill | Role |
|---|---|
| `debugging-root-cause` | Systematic debugging when a fix attempt fails — no guess-patch loops |
| `deploy-production-readiness` | Env config, pre-launch checklist, post-deploy verification, handover |

## Install
**Claude Code:** copy skill folders into `.claude/skills/` (project) or `~/.claude/skills/` (global).
**Cowork / Claude.ai:** upload folders or install the `.skill` files.

## Use
Copy `CLAUDE.md.template` into your project folder as `CLAUDE.md`, fill in the project brief, then:
> "Develop this project following the instructions, using the iterative-perfection-loop skill. Don't stop until exit criteria are met."
