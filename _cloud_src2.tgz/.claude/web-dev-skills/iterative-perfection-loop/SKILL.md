---
name: iterative-perfection-loop
description: The master workflow for building a web project end-to-end until it reaches a polished, production-ready state. ALWAYS use this skill when the user gives you a project folder with instructions and asks you to "develop the project", "build it fully", "review and fix everything", "make it perfect", or any request implying a full build + review + fix cycle. This skill orchestrates all other skills (web-app-architect, database-design, frontend-design-system, asset-production, ui-animations, content-localization, api-integrations-webhooks, visual-self-review, design-benchmarking, functionality-qa, code-quality-review, ux-design-review, seo-performance-optimization, gap-analysis, debugging-root-cause, deploy-production-readiness) in repeated rounds, with mandatory user approval gates.
---

# Iterative Perfection Loop

You are not done when the code runs. You are done when a full review round finds **zero blocking issues and zero high-priority gaps**. This skill defines the loop that gets you there.

## The Loop

```
ROUND N:
  1. PLAN      → web-app-architect skill (round 1 only, or when redesign is needed)
                 [GATE A after art direction, before any UI code — round 1 only]
  2. DEVELOP   → build/fix according to current plan + open issues list
  3. REVIEW    → run ALL review passes in the table below (7 for public sites)
  4. ANALYZE   → gap-analysis skill: consolidate findings, classify, decide
                 [GATE B after round 1's analyze step only]
  5. DECIDE    → if blocking/high issues remain → go to ROUND N+1
                 if only MEDIUM/LOW remain → GATE C: present for sign-off
```

Run a **minimum of 2 full rounds** before declaring anything finished. The first build always has gaps. Cap at 5 rounds unless the user asks for more — after 5, present remaining items and let the user prioritize.

## Round 1: Plan + Build

1. Read EVERY file in the project folder first: instructions, briefs, existing code, assets, README, CLAUDE.md. Build a requirements checklist — every feature, page, behavior, and constraint mentioned. Write it to `PROJECT_STATE.md` (see tracking section).
2. Consult `web-app-architect` for stack/structure decisions; `database-design` for any data model.
3. Consult `frontend-design-system` BEFORE writing any UI code (including its reference-gathering + ART_DIRECTION.md phase); `content-localization` for all visible text (no lorem ipsum) and any AR/FR/RTL needs.
4. Build the full project. Use `asset-production` for every visual asset (no placeholders, no default favicon), `ui-animations` for motion, `api-integrations-webhooks` for any external service/webhook/queue work.
5. Verify it builds and runs (`npm run build`, dev server smoke test) before entering review.

**During any development/fix work**: if a bug survives one fix attempt, STOP guessing and switch to `debugging-root-cause`. Commit a git checkpoint at the end of every round (`git add -A && git commit -m "round N"`) so redesigns can be rolled back.

## Review Phase (every round, every applicable pass, no skipping)

Run each as a separate, focused pass. Do not blend them — a blended review misses things.

| Pass | Skill | What it catches |
|---|---|---|
| 1. Visual | `visual-self-review` | Screenshot every route at 3 viewports; critique what is SEEN — layout breaks, generic look, hierarchy. Run this FIRST |
| 2. Functionality | `functionality-qa` | Broken features, edge cases, error states, every button/form/flow |
| 3. Code quality | `code-quality-review` | Bugs, security, performance, maintainability, dead code |
| 4. UX & accessibility | `ux-design-review` | Confusing flows, contrast, keyboard nav, mobile, empty states |
| 5. Design fidelity | `frontend-design-system` (audit mode) | Generic/templated look, inconsistent spacing/type/color, brief mismatch |
| 6. SEO & perf* | `seo-performance-optimization` | Missing meta/OG, Core Web Vitals, bundle weight (*public-facing sites: every round; internal apps: final round only) |
| 7. Benchmark** | `design-benchmarking` | Side-by-side vs live reference sites (**premium/marketing sites: round 1 and final round minimum) |

Each pass outputs a findings list with file:line references where possible.

## Analyze + Decide Phase

Use `gap-analysis` to merge all findings into one prioritized table:

- **BLOCKING** — broken functionality, security issues, build failures, missing required features
- **HIGH** — bad UX, visual inconsistency, performance problems, accessibility failures
- **MEDIUM** — polish, refactors, minor visual issues
- **LOW / NICE-TO-HAVE** — ideas, enhancements

For each item decide: **FIX** (targeted change), **REDESIGN** (the approach itself is wrong — rework the component/page/flow), or **DEFER** (log it, tell the user).

Redesign is the right call when: 3+ findings cluster on the same component, the design looks generic/AI-templated, or fixing piecemeal would fight the architecture.

## State Tracking (mandatory)

Maintain `PROJECT_STATE.md` at the project root, updated every round:

```markdown
# Project State — Round N
## Requirements checklist
- [x] Feature A — done, verified round 2
- [ ] Feature B — in progress
## Open issues (from last review)
| # | Severity | Area | Issue | Decision | Status |
## Resolved this round
## Deferred (user decision needed)
## Gates
- Gate A (art direction): approved / pending / adjusted
- Gate B (round-1 visuals): ...
- Gate C (final sign-off): ...
## Round log
- Round 1: built core, 14 issues found
- Round 2: fixed 12, redesigned navbar, 3 new issues found
```

This file is your memory across the loop. Never trust your recollection over it.

## User Approval Gates (mandatory — the user's eyes are part of the system)

Pause and present to the user at exactly these three points. Keep each presentation short: the artifacts + 1-3 specific questions. Do NOT pause anywhere else — between gates, decide and proceed.

1. **Gate A — Art direction (before building UI)**: present ART_DIRECTION.md + reference links + palette/type choices. Ask: "approve this direction, or adjust before I build?" One round of adjustment max, then proceed.
2. **Gate B — First visuals (after round 1 review)**: present the round-1 screenshots (key pages, desktop + mobile) + the gap-analysis decision table. Ask: "anything here you'd redirect before I continue?" Taste corrections cost 10x less here than at the end.
3. **Gate C — Pre-final (before declaring done)**: present final screenshots, benchmark verdicts, deferred-items list. Ask for sign-off or final change list.

If the user is unavailable, note the gate as pending in PROJECT_STATE.md and continue with stated assumptions — but never skip presenting Gates A and C.

## Exit Criteria

Declare the project finished only when ALL are true:
1. Every requirement from the original instructions is checked off
2. Latest review round found zero BLOCKING and zero HIGH issues
3. Project builds with no errors; lint passes or warnings are justified
4. Every core user flow executed end-to-end with Playwright (or traced where execution is impossible) in the final round, passing
5. Design audit pass on the FINAL screenshots says "intentional, consistent, on-brief" — not "acceptable" — and the ART_DIRECTION.md signature element is present
6. `design-benchmarking` verdict: at minimum "holds up" on first-screen impact and craft vs references (premium sites)
7. Gate C presented to the user

Then run `deploy-production-readiness` if the project ships (or hand the user its checklist), and write a final summary: what was built, rounds taken, issues fixed per round, deferred items, and how to run/deploy the project.

## Anti-patterns

- ❌ Declaring done after the first build compiles
- ❌ Reviewing your own code in the same pass you wrote it — always finish development, then switch into reviewer mindset (assume the code is guilty)
- ❌ Fixing issues one at a time as you find them mid-review — finish the full review, then batch fixes (the user prefers batched planning, one-at-a-time execution)
- ❌ Letting "fix" creep when "redesign" is needed — patching a fundamentally weak design wastes rounds
- ❌ Losing track of earlier findings — that's what PROJECT_STATE.md is for
