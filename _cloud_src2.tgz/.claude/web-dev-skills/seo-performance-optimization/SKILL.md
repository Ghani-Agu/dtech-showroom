---
name: seo-performance-optimization
description: SEO, Core Web Vitals, and page performance for websites and web apps. ALWAYS use for marketing sites, landing pages, showrooms, e-commerce, or any public-facing site — even if the user doesn't mention SEO. Also use when the user says "slow", "performance", "Lighthouse", "Google ranking", "meta tags", or during the final review round of any public site.
---

# SEO & Performance

## SEO essentials (every public page)
- Unique `<title>` (50-60 chars) + meta description (150-160) per page — Next.js `metadata` export / `generateMetadata` for dynamic routes
- One `<h1>` per page matching search intent; semantic heading tree
- OpenGraph + Twitter card tags with a real OG image (1200×630) — clients WILL share links on Facebook/WhatsApp; in MENA this is how sites spread
- `sitemap.xml` + `robots.txt` (Next: `app/sitemap.ts`, `app/robots.ts`); canonical URLs
- Structured data (JSON-LD) where it fits: LocalBusiness, Product, Organization, BreadcrumbList
- Multilingual sites: `hreflang` alternates, `lang`/`dir` correct per locale, localized titles/descriptions (not just translated body)
- Descriptive URLs (`/products/cctv-cameras` not `/p?id=7`); 301s for changed paths

## Core Web Vitals targets
- **LCP < 2.5s**: hero image via `next/image` with `priority`; preload hero font; server-render above-fold content (no client fetch for it)
- **CLS < 0.1**: width/height on every image; reserve space for dynamic content; `next/font` (no FOUT shift); skeletons match final layout
- **INP < 200ms**: break up heavy client JS; defer non-critical scripts; debounce expensive handlers

## Weight budget
- Images: WebP/AVIF via next/image, correct `sizes`, lazy below fold; hero ≤ 200KB
- JS: check bundle (`next build` output or `@next/bundle-analyzer`); dynamic-import heavy components (charts, 3D, editors); 3D scenes lazy-load AFTER LCP
- Fonts: subset (latin + arabic only as needed), max 2 families, `display: swap`
- Third-party scripts: `next/script` strategy `lazyOnload`; question every one

## Audit procedure (review rounds)
1. Run Lighthouse (`npx lighthouse <url> --output=json` or PageSpeed Insights on deployed URL) — targets: Performance ≥ 90 (marketing) / ≥ 75 (app), SEO ≥ 95, A11y ≥ 90
2. Verify meta tags present in server-rendered page source (not client-injected)
3. Test OG preview (paste link in WhatsApp / use an OG preview tool)
4. Check mobile performance specifically — assume mid-range Android on 4G; that's the real MENA audience
5. Findings table with severity → gap-analysis
