---
name: ux-design-review
description: User experience and accessibility review of a web app — flows, clarity, feedback, mobile usability, and WCAG accessibility. Use during every review round, and whenever the user mentions UX, usability, "is it easy to use", "review the experience", accessibility, a11y, or mobile-friendliness. Distinct from visual design audit (frontend-design-system) — this is about whether users can actually accomplish their goals.
---

# UX & Accessibility Review

Walk the app as three personas: a first-time user, a daily power user, and a user on a cheap Android phone with mediocre connectivity (the realistic MENA SMB user). Note every moment of confusion or friction.

## 1. Flows & clarity
- For each core task: how many steps/clicks? Could any be removed?
- Is the next action always obvious on every screen? One primary CTA per view.
- First-time experience: does an empty account explain itself (empty states with guidance + CTA), or is it a dead dashboard?
- Labels: do buttons say what happens ("Save changes", "Send invoice") not vague verbs ("Submit", "OK")?
- Destructive actions: confirmation with consequence stated ("This deletes 14 messages — cannot be undone"), and the dangerous button is NOT the visually primary one.
- Jargon check: would the actual target user (e.g., a distributor owner, not a developer) understand every word?

## 2. Feedback & system status
- Every action gives feedback within 100ms (pressed state) and resolves visibly (toast/inline confirmation/updated data)
- Long operations: progress indication; the UI never just freezes
- Errors: human language, say what went wrong AND what to do next, never raw error codes/stack traces
- Unsaved changes: warned before navigating away?

## 3. Mobile usability
- Test at 375px width: nothing cut off, no horizontal scroll, nav usable
- Touch targets ≥44×44px with spacing between adjacent ones
- Forms: correct keyboard types (`inputmode`, `type=email/tel`), no tiny inputs, labels visible (not placeholder-only)
- Sticky elements don't eat the viewport; modals scrollable and dismissible

## 4. Accessibility (WCAG 2.1 AA essentials)
- **Keyboard**: tab through every page — logical order, visible focus ring everywhere, no traps, Escape closes modals, focus returns to trigger
- **Semantics**: real `<button>`/`<a>` (not clickable divs), heading hierarchy (one h1, no skips), landmarks (nav/main/footer), form inputs with `<label>`
- **Contrast**: ≥4.5:1 normal text, ≥3:1 large text & UI components — actually check, especially text-on-gradient and muted grays
- **Images/icons**: alt text on meaningful images, `aria-hidden` on decorative; icon-only buttons have `aria-label`
- **Motion**: `prefers-reduced-motion` respected
- **Announcements**: form errors associated via `aria-describedby`; toasts in a live region
- **RTL**: if Arabic is supported, full layout mirroring works, not just translated strings

## 5. Content & trust
- Tone consistent; dates/numbers/currency localized correctly (DZD formatting, Arabic numerals policy decided and consistent)
- Loading skeletons match final layout (no jarring shifts — CLS)
- 404/500 pages exist, are branded, and link home

## Output
Findings table with severity + screen + persona affected + recommendation. Anything that blocks task completion = BLOCKING. Confusion/friction = HIGH. Polish = MEDIUM/LOW. Feed to gap-analysis.
