---
name: frontend-design-system
description: Visual design direction, design tokens, typography, color, spacing, and layout for web UIs — both for CREATING new UI and for AUDITING existing UI for design quality. Use this skill before writing any UI code, and again during review rounds as a "design fidelity audit". Triggers include "design", "make it look good/modern/premium", "redesign", "the UI looks generic", landing pages, dashboards, admin panels, glassmorphism, dark mode, or any task producing visible interface.
---

# Frontend Design System

Two modes: **CREATE** (before building UI) and **AUDIT** (during review rounds).

## CREATE mode

### 0. References before rules (mandatory for premium work)
Rules prevent bad design; references produce distinctive design. Before any tokens or code:
1. **Gather 3-5 reference sites** in the project's quality tier and adjacent industry (search awwwards/godly.website/land-book level work, or use references the user provides). For each, note in one line WHAT makes it work: the type scale move, the layout rhythm, the color restraint, the signature interaction.
2. **Write ART_DIRECTION.md** (½ page max): design intent sentence, the 2-3 specific moves stolen/adapted from references (e.g., "oversized serif display numerals like ref A", "asymmetric split-hero like ref B"), the palette with hex values, the type pairing, and ONE signature element that makes this site memorable (a distinctive hero treatment, an unusual grid, a custom interaction, a recurring graphic motif).
3. Every page built afterward must be checkable against ART_DIRECTION.md. No signature element = template territory.

### 1. Pick an intentional direction first
Never start typing JSX before answering: what should this feel like? (e.g., technical & precise / warm & human / premium & minimal / bold & energetic). Write one sentence of design intent in ART_DIRECTION.md. Every choice below must serve it.

### 2. Define tokens before components
Set these as CSS variables / Tailwind theme BEFORE the first component:

```css
@theme {
  /* Color: 1 base neutral scale + 1 brand accent + semantic (success/warn/error) */
  /* Type: 2 fonts max — one display, one body. Sizes on a scale (1.25 ratio) */
  /* Spacing: 4px grid. Radius: pick ONE family (e.g., 8/12/16) and stick to it */
  /* Shadows: 2-3 elevations max, defined once */
}
```

### 3. Rules that prevent "AI-generated template" look
- **Typography carries the design.** Strong size contrast between headings and body (e.g., 3rem display vs 0.95rem body), tight letter-spacing on large headings, generous line-height on body.
- **One accent color, used sparingly.** Not every button/icon/border gets the brand color. Avoid the purple-gradient-on-white cliché unless asked.
- **Whitespace is a feature.** Sections breathe (py-20+ on landing sections). Cards don't touch.
- **Real content rhythm**: vary section layouts (full-bleed, split, grid, centered) — never 6 identical centered-text-with-3-cards sections.
- **Details**: consistent icon set (lucide), proper hover/focus/active states on EVERY interactive element, subtle borders (`border-white/10` on dark, `border-black/5` on light) instead of heavy shadows.
- **Dark/glass aesthetics** (if used): deep navy/charcoal base, frosted cards (`backdrop-blur-xl bg-white/5 border border-white/10`), 1-2 ambient gradient orbs max, never on light backgrounds.

### 3b. Bespoke visual assets (what separates premium from template)
Stock-feeling pages are the #1 tell. Prefer, in order:
- **Custom SVG graphics**: build illustrations, abstract motifs, diagrams, logos-as-pattern, decorative geometry yourself — original SVG beats any stock image
- **CSS/canvas-generated texture**: gradients meshes, noise overlays, grain, generative patterns tied to the brand palette
- **Product/real photos** supplied by the user — request them in PROJECT_STATE.md deferred items if missing, and design layouts that will receive them (correct aspect ratios reserved)
- Generic stock photos: last resort, and never the smiling-team-at-laptop genre
Each major section should have at least one designed visual element — pure text+icon cards everywhere reads as template.

### 4. RTL & Arabic
- Amiri or IBM Plex Sans Arabic for Arabic text; test that the chosen display font has Arabic glyphs or pair fonts.
- Logical properties only; mirror directional icons; numbers stay LTR.

### 5. Responsive
Design mobile-first. Check at 375px, 768px, 1280px. Nav collapses properly; tables become cards or scroll containers; touch targets ≥44px.

## AUDIT mode (review rounds)

Audit from the `visual-self-review` screenshots, not from code, and check every page against ART_DIRECTION.md. Go page by page and grade against this checklist. Output findings with severity:

1. **Consistency**: same radius family everywhere? Same spacing rhythm? Same button styles for same actions? One shadow system?
2. **Hierarchy**: can you tell the most important element on each screen in 1 second? Is anything competing?
3. **Typography**: scale respected? Line lengths ≤ ~75ch? Orphan headings? Contrast ratios ≥4.5:1 body, 3:1 large text?
4. **Color discipline**: accent overused? Semantic colors used correctly (red = destructive only)?
5. **States**: hover, focus-visible, active, disabled, loading, empty, error — present on every interactive element and data view?
6. **Genericness test**: does any page look like a default template? Is the signature element from ART_DIRECTION.md present and working? If templated or signature missing → flag for REDESIGN, not patching.
7. **Brief fidelity**: re-read the original design instructions; list every deviation.

Verdict per page: **on-brief / needs fixes / needs redesign**.
