---
name: api-integrations-webhooks
description: Building reliable third-party integrations — webhooks (Meta/WhatsApp/Instagram, Stripe, etc.), external API calls, background jobs/queues, retries, and idempotency. Use whenever the project connects to any external service, receives webhooks, sends messages/emails, calls AI APIs, or processes jobs asynchronously. Also use when debugging "the webhook isn't firing" or "messages are duplicated/lost" issues.
---

# API Integrations & Webhooks

## Receiving webhooks (the right way)
1. **Verify before processing**: check the signature (e.g., Meta `X-Hub-Signature-256` HMAC over RAW body, Stripe `stripe-signature`) — compute over the raw request bytes, BEFORE JSON parsing. Reject on mismatch with 401.
2. **Respond fast**: return 200 within seconds, then process. Heavy work (AI calls, DB writes, sending replies) goes to a queue (BullMQ) or `waitUntil`. Slow handlers → provider retries → duplicates.
3. **Idempotency**: providers WILL deliver the same event twice. Store processed event IDs (unique constraint) and skip repeats. Every external-side effect (send message, charge) must be safe to retry.
4. **Verification handshake**: Meta-style GET challenge (`hub.verify_token` + echo `hub.challenge`) handled separately from POST events.
5. **Log every received event** (id, type, timestamp, processing result) — debugging webhooks without logs is guessing.

## Calling external APIs
- Wrap each provider in one client module (`lib/providers/<name>.ts`): auth, base URL, typed methods. Never scatter fetch calls.
- **Timeouts always** (AbortController, 10-30s); a hung external call must not hang your route
- **Retry with backoff** on 429/5xx (3 attempts, exponential + jitter); NEVER retry non-idempotent calls without an idempotency key
- Handle rate limits explicitly: read `Retry-After`, queue or delay
- Parse responses with Zod — external APIs change without telling you; fail loudly with the raw payload logged
- Secrets server-side only; per-tenant credentials (BYOK) encrypted at rest, never logged

## Background jobs (BullMQ pattern)
- Job payload = IDs, not full objects (fetch fresh data in the worker)
- Configure: attempts (3-5), backoff, `removeOnComplete`, dead-letter handling for final failures — failed jobs must surface somewhere visible
- Workers idempotent (same rule as webhooks); concurrency tuned to provider rate limits
- Graceful shutdown: finish in-flight jobs on deploy

## Testing integrations
- Local webhooks: tunnel (ngrok/cloudflared) + provider test events; keep a `curl` script with a sample signed payload for replay
- Mock provider modules in tests; one happy-path + one failure-path test per integration minimum
- Sandbox/test mode for everything before prod keys (Meta test users, Stripe test mode)

## Review checklist (for review rounds)
Signature verified? Raw body used? 200 returned fast? Duplicates handled? Timeouts set? Retries safe? Failures visible (logged + surfaced)? Secrets out of logs? Per-tenant isolation in multi-tenant webhooks (route event → correct tenant by page/business ID, never trust payload alone)?
