---
name: deploy-production-readiness
description: Prepare and verify a web project for production deployment — environment config, hosting setup, pre-launch checklist, and post-deploy verification. Use whenever the user mentions deploying, hosting, Vercel, Netlify, going live, launching, handing a project to a client, or as the FINAL phase after the iterative-perfection-loop exit criteria are met. Also use when a deployed site is broken in production but works locally.
---

# Deploy & Production Readiness

## Pre-deploy checklist
- `npm run build` clean locally with production env values (not dev defaults)
- All env vars inventoried in `.env.example` with comments; secrets generated fresh for prod (never reuse dev keys); no secrets in repo history
- Hardcoded localhost/dev URLs hunted down (`grep -ri "localhost\|127.0.0.1" src/`)
- Database: migrations applied (`prisma migrate deploy`, never `db push` in prod), seed strategy decided, connection pooling configured (Supabase: pooled connection string for serverless)
- Auth callback URLs / OAuth redirect URIs updated for the prod domain
- Webhook URLs registered against prod domain; signatures verified
- Error pages (404/500) exist; `robots.txt` correct (block staging, allow prod)
- Remove debug endpoints, test accounts, console.logs

## Platform setup (Vercel default)
- Env vars set per environment (Production / Preview / Development) — preview deployments must NOT touch prod DB
- Custom domain + HTTPS verified; www/apex redirect decided
- Region close to users (fra1/cdg1 for Algeria/MENA)
- Function timeout/memory adjusted for heavy routes (AI calls, file processing)
- For static sites: static export on Netlify/Vercel — don't pay for SSR you don't use

## Post-deploy verification (do not skip)
1. Smoke test EVERY core flow on the live URL (signup, login, core action, payment/webhook if any)
2. Check live env: correct DB (not dev!), emails actually send, OAuth works on prod domain
3. Mobile device test on the real URL
4. Trigger one real webhook end-to-end if integrations exist
5. Check function logs for errors during the first session

## Operations basics
- Error monitoring: Sentry (free tier) or at minimum platform log review — silent prod errors are how customers churn
- Uptime ping (UptimeRobot or similar free tier) for client projects
- DB backup strategy stated in README (Supabase: PITR or scheduled dumps)
- Client handover doc: URLs, admin access process, where env vars live, how to redeploy

## Rollback plan
Know before deploying: instant rollback to previous deployment on Vercel; DB schema changes deployed separately from breaking code (expand → migrate → contract pattern for column changes).
