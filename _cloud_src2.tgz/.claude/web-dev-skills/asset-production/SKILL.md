---
name: asset-production
description: Produce the actual custom visual assets a premium website needs — original SVG illustrations, hero graphics, background textures, patterns, icons, OG images, favicons, and logo treatments. Use whenever a design calls for any visual element beyond text and layout, when a section feels empty or stock-like, when OG/favicon files are missing, and ALWAYS instead of placeholder images or generic stock photos.
---

# Asset Production

A premium site is premium because its visuals exist nowhere else. Produce real asset files; never leave "image goes here" boxes or default favicons.

## Asset inventory (check per project)
favicon set (svg + 32/180/512 png + manifest) • OG image 1200×630 per key page • hero visual • per-section graphics/illustrations • background texture/pattern • empty-state & 404 illustrations • loading marks. Missing items = findings.

## Original SVG illustration technique
Build in layers, in the brand palette only (CSS-variable-friendly: use `currentColor`/explicit brand hexes from ART_DIRECTION.md):
1. **Geometry base**: compose from primitives (rects, circles, paths) on a consistent grid; pick ONE illustration language per project — flat geometric / line-art mono-weight / isometric / organic blobs — and never mix
2. **Depth**: 2-3 tones of one hue + a single accent beats rainbow; subtle `<linearGradient>`; offset duplicate shapes for shadow
3. **Texture pass**: `<feTurbulence>` noise overlay at 3-6% opacity kills the "vector sterile" look:
```svg
<filter id="grain"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2"/>
<feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope="0.05"/></feComponentTransfer>
<feComposite operator="over" in2="SourceGraphic"/></filter>
```
4. **Quality bar**: view the rendered SVG via screenshot at actual display size. Clip-art symmetry, default-looking shapes, or inconsistent stroke weights → redo.

## Backgrounds & textures (CSS, no image files)
- **Mesh gradient**: 3-4 stacked `radial-gradient`s of brand hues at low saturation on a deep base
- **Grain**: inline SVG turbulence as `background-image` data-URI over the mesh
- **Patterns**: repeating SVG tile (dots/grid/topo lines) at 2-4% opacity for section texture
- Glassmorphism orbs: max 2, blurred 80-120px, behind content, animated drift optional

## Icons
One library (lucide), one size scale, one stroke weight everywhere. Custom icons only if matching that exact stroke/grid. Never mix filled and outlined styles.

## OG images & favicon
- OG: generate programmatically (canvas/sharp/satori script) — brand background + page title in display font + logo mark; verify at WhatsApp-preview size (readable when tiny)
- Favicon: simplified mark, NOT the full logo; test visibility at 16px on dark and light tabs

## Photography (when the user supplies it)
Design the treatment, don't just drop files in: consistent duotone/overlay tint to unify mixed-quality photos; fixed aspect ratios per slot; `next/image` with correct sizes. No photos yet → design the layout for them, fill with brand-toned placeholder gradients + label, log in PROJECT_STATE.md deferred.

## Review checklist
Default favicon still present? Any stock-feeling or empty section? Illustration language consistent across pages? OG renders correctly when link is shared? Every asset in brand palette?
