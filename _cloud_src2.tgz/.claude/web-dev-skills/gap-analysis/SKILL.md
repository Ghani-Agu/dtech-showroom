---
name: gap-analysis
description: Consolidate all review findings, identify gaps against requirements, prioritize, and decide fix vs redesign vs defer for each item. Use after completing review passes in any build cycle, and whenever the user asks "what's missing", "what are the gaps", "what should be fixed", "analyze the project", or "decide what to redesign". This skill produces the action plan for the next development round.
---

# Gap Analysis & Decision

Input: findings tables from ALL review passes — visual-self-review, functionality-qa, code-quality-review, ux-design-review, frontend-design-system audit, seo-performance-optimization, and design-benchmarking — plus the original requirements checklist.

## Step 1 — Requirements gap scan
Beyond reported issues, diff the current state against the ORIGINAL instructions line by line:
- Required features missing entirely (these are BLOCKING even if nothing "broke")
- Features built differently than specified — deviation justified or accidental?
- Implicit expectations unmet (a "store" implies search; a "dashboard" implies the numbers are correct; "admin panel" implies user management)

## Step 2 — Merge & deduplicate
Combine all findings into one table. Merge duplicates reported by multiple passes (note the multi-pass hit — it signals importance). Cluster findings by component/page.

## Step 3 — Severity (re-grade with fresh eyes)
- **BLOCKING**: broken core functionality, security holes, data loss risk, missing required features, build failures
- **HIGH**: degraded UX on main flows, visual inconsistency on key pages, performance users will notice, a11y failures, error states missing
- **MEDIUM**: secondary-flow issues, refactors that reduce future bug risk, polish on visible surfaces
- **LOW**: enhancements, nice-to-haves, micro-polish

## Step 4 — Decide per item: FIX / REDESIGN / DEFER

**REDESIGN** (rework the approach, don't patch) when any of:
- ≥3 findings cluster on the same component/page
- The design audit verdict was "generic/templated"
- The architecture fights the requirement (e.g., client state where server state belongs; component doing 4 jobs)
- Previous round already "fixed" this area and it broke again — patching is failing

**FIX** when the approach is sound and the issue is localized.

**DEFER** when: LOW severity AND (large effort OR depends on user input — e.g., business decisions, content, credentials). Deferred items must be listed for the user; never silently dropped.

## Step 5 — Plan the next round
Order of work: BLOCKING fixes → redesigns (they invalidate adjacent fixes, so do them before fixing inside them) → HIGH fixes → MEDIUM if round budget allows.
Write the plan into PROJECT_STATE.md: each item with its decision, target files, and a one-line approach. Estimate whether this is plausibly the FINAL round (only MEDIUM/LOW remain after) and say so.

## Step 6 — Regression guard
List every area touched by the upcoming fixes; next round's QA pass MUST re-test those areas plus anything that shares code with them. Fixes cause regressions — assume it.

## Output
Updated PROJECT_STATE.md: prioritized decision table + next-round plan + deferred list. Then hand control back to iterative-perfection-loop to execute the round.
