---
name: database-design
description: Database schema design, Prisma modeling, migrations, indexing, seeding, and query patterns (including pgvector for AI features). Use when creating or changing any data model, writing Prisma schemas, planning relations, adding search, fixing slow queries, or whenever a project stores data. Trigger on "schema", "database", "model", "migration", "slow query", "pgvector", "embeddings".
---

# Database Design

## Schema rules
- Every table: `id` (cuid/uuid), `createdAt`, `updatedAt`. Soft-delete (`deletedAt`) only where history matters — and then EVERY query must filter it (helper/extension, not memory).
- **Multi-tenant**: `tenantId` on every tenant-owned table, indexed, in every unique constraint (`@@unique([tenantId, slug])`), in every query.
- Relations explicit with `onDelete` behavior CHOSEN (Cascade vs Restrict vs SetNull) — Prisma's default will surprise you. Ask: "if the parent dies, what should happen?"
- Enums for closed sets (status, role); String for open sets. Status fields = enum + document the state machine (which transitions are legal).
- Money: `Int` (centimes) or `Decimal` — never Float. Phone numbers: String (leading zeros, +213).
- Normalize until it hurts joins, then denormalize deliberately (e.g., cached counts) and document who updates the copy.

## Indexing
- Index: every FK used in joins/filters, every column in WHERE/ORDER BY of hot queries, tenant-scoped composites (`@@index([tenantId, createdAt])`)
- Don't index: tiny tables, write-heavy columns nobody filters on
- Verify with `EXPLAIN ANALYZE` on the real query when something is slow

## Migrations
- Dev: `prisma migrate dev`. Prod: `prisma migrate deploy`. NEVER `db push` against prod data.
- Breaking changes via expand→migrate→contract: add new column nullable → backfill → make required/drop old. Never rename in place on a live table.
- Review generated SQL before deploy; data backfills as scripts, tested on a copy first.

## Seeding
- `prisma/seed.ts` with realistic data: Arabic/French names, real-looking products with prices in DZD, edge cases baked in (long strings, empty optional fields, one of each status)
- Idempotent (upsert) so reseeding doesn't duplicate

## pgvector / search
- Embedding column `vector(dims)` matching the model (Voyage: check model dims); HNSW index for >10k rows (`vector_cosine_ops`)
- Hybrid search: combine vector similarity + keyword (ILIKE/tsvector) — vector alone misses exact SKUs/model numbers; keyword alone misses paraphrase. Merge + rerank.
- Store embedding model name/version alongside vectors — model changes invalidate them all

## Query review checklist (review rounds)
N+1s (loops with awaits → `include`/`in`)? `select` only needed fields on wide tables? Pagination on every list (cursor-based for infinite scroll)? Transactions around multi-write invariants (`$transaction`)? Tenant filter on EVERY query (grep for raw `findMany` without where.tenantId)?
