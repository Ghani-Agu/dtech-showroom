---
name: debugging-root-cause
description: Systematic root-cause debugging when something is broken and the fix isn't obvious — build failures, runtime errors, "works locally but not deployed", intermittent bugs, or any issue that survived a first fix attempt. ALWAYS use this skill instead of guess-and-patch when a bug resists the first fix, when the same issue reappears across review rounds, or when an error message is unclear.
---

# Root-Cause Debugging

Rule: after ONE failed fix attempt, stop patching and switch to this method. Guess-patch loops burn rounds and add regressions.

## The method

1. **Reproduce reliably first.** A bug you can't reproduce on demand is a bug you can't verify as fixed. Write down the exact repro steps/input. If intermittent, find what makes it intermittent (timing? data? order?) before anything else.
2. **Read the actual error.** The FULL error: stack trace top frame in YOUR code (not framework frames), error cause chains (`error.cause`), server logs not just browser console. Copy the exact message — don't paraphrase it to yourself.
3. **State a hypothesis before changing code.** "I believe X because Y. If true, then Z should be observable." Then check Z — with a log, a breakpoint, a curl, a DB query. No hypothesis = no edit.
4. **Bisect the path.** Find the last point where data/state is correct and the first point where it's wrong. Add temporary logging at boundaries: request received → validated → DB result → transform → response → client state → render. The bug lives between the last good and first bad checkpoint.
5. **Diff against the last working state.** `git diff` / `git log -p` since it last worked. Most bugs are in the most recent change — but verify, don't assume.
6. **Fix the cause, then hunt siblings.** Same wrong pattern elsewhere? (grep for it). Then remove debug logging, and re-run the ORIGINAL repro to confirm.
7. **Record it.** One line in PROJECT_STATE.md: symptom → root cause → fix. Repeated causes signal a needed redesign (feed to gap-analysis).

## Common culprits by symptom (check these FIRST)
- **Works locally, broken deployed**: env var missing/different in prod • case-sensitive imports (Windows dev → Linux deploy: `./Button` vs `./button`) • dev-only behavior (hot reload masking stale state) • DB difference • Node version
- **Works once, fails on second run**: missing cleanup, cached value, non-idempotent operation, unique constraint
- **Intermittent**: race condition (two awaits racing), missing await, webhook retry duplicates, timezone/clock
- **Hydration errors (Next.js)**: Date/random/locale rendering differently on server vs client • browser-only API in render path • invalid HTML nesting
- **"undefined is not a function/property"**: API response shape changed or error response parsed as success — log the raw payload
- **Styles broken**: Tailwind class built dynamically by string concatenation (purged) — use full class names or safelist
- **Build fails only in CI/deploy**: type errors that dev server tolerated (`tsc --noEmit` locally), missing dep in package.json (works via hoisting locally)

## Anti-patterns
- ❌ Changing 3 things at once (you won't know which one mattered)
- ❌ "Fixing" by try/catch-and-ignore — that hides, not fixes
- ❌ Deleting and rewriting a whole file to dodge understanding the bug
- ❌ Declaring fixed without re-running the original repro
