---
name: design-benchmarking
description: Benchmark the project's design against live top-tier reference websites by screenshotting BOTH and comparing side-by-side. Use during design review rounds of any premium/high-stakes website, whenever the user wants "best possible" quality, agency-level results, or asks "is this good enough", and always at least once before final delivery of a marketing/showcase site.
---

# Design Benchmarking

Self-review has a blind spot: with nothing to compare against, "pretty good" feels like "great". This skill removes the blind spot by putting the project next to the best work in the world, at the same viewport, on the same screen.

## 1. Capture the references
Take the 3-5 reference sites from ART_DIRECTION.md (or find them now — premium sites in the same industry/tier; awwwards/godly.website/land-book caliber). Screenshot each with the same Playwright script used in visual-self-review:

```js
// same viewports as the project: 375 / 768 / 1440, fullPage
await page.goto('https://reference-site.com', { waitUntil: 'networkidle' });
await page.waitForTimeout(1500); // let their animations settle
await page.screenshot({ path: `benchmarks/refA-desktop.png`, fullPage: true });
```

If a reference blocks headless browsers, pick another — don't skip the step.

## 2. The comparison (view images in pairs: ours ↔ theirs)
For each pair at desktop and mobile, answer in writing — brutally:

- **First-screen impact**: cover the URLs. If both heroes were shown to a stranger, which company looks more expensive? Why, specifically — type scale? imagery? spacing? color confidence?
- **Type scale courage**: measure roughly from the screenshots — their display-to-body size ratio vs ours. Premium sites are usually far bolder (6-10x) than safe defaults (2-3x).
- **Density & breathing room**: count distinct elements in the first viewport. Are we cramming where they curate?
- **Visual interest curve**: scroll both full-page captures. Where does theirs surprise (layout shift, scale change, art moment)? Where does ours flatline into repeated card grids?
- **Craft details**: their button/card/nav close-up vs ours — border subtlety, shadow quality, alignment precision.
- **Signature**: name their memorable element in 5 words. Can you do the same for ours? If not → finding.

## 3. Verdict & extraction
- Score ours per category: **holds up / noticeably weaker / not in the same league**
- For every "weaker": extract the SPECIFIC transferable move (not "make it better" — "hero type to ~9rem with tight leading like ref B", "replace third card grid with full-bleed split section like ref C")
- Feed findings to gap-analysis. "Not in the same league" on first-screen impact = REDESIGN of that page, automatically.

## Rules
- Adapt moves, never clone: layout principles and scale courage transfer; copying a specific site's identity doesn't (and reference imagery/illustrations are theirs — produce our own via asset-production).
- Re-run after redesigns: the comparison is the test of whether the redesign actually closed the gap.
- Final round requires "holds up" on first-screen impact and craft details at minimum.
