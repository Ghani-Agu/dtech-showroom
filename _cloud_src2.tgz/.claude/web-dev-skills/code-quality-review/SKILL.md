---
name: code-quality-review
description: Deep code review for correctness, security, performance, and maintainability. Use during every review round of a build, after writing any significant amount of code, and whenever the user says "review the code", "check for bugs", "is this secure", "clean this up", or "refactor". Reviews TypeScript/JavaScript, React/Next.js, API routes, database queries, and config.
---

# Code Quality Review

Review in this order — security and correctness before style. Read the actual code; never review from memory of what you wrote.

## 1. Security (BLOCKING tier)
- **Secrets**: no API keys/tokens/credentials in code, comments, client bundles, or git history. `NEXT_PUBLIC_` only for truly public values.
- **Injection**: all DB access via ORM/parameterized queries; no string-built SQL; no `dangerouslySetInnerHTML` with user content (sanitize if unavoidable).
- **Auth on the server**: every API route / server action re-checks session AND authorization. Hidden UI is not security.
- **Multi-tenant isolation**: every query scoped by tenantId derived from session, never from request body/params.
- **Validation at boundaries**: Zod (or equivalent) parses every external input — API bodies, search params, webhooks, form data. Webhook signatures verified.
- **Mass assignment**: never spread `req.body` into create/update — whitelist fields.
- **Rate limiting** on auth endpoints and expensive operations.

## 2. Correctness
- Async: missing `await`, unhandled promise rejections, race conditions on rapid actions
- React: stale closures in effects/callbacks, missing/wrong dependency arrays, state updates after unmount, keys on lists (stable IDs, not index)
- Null safety: every `.property` chain on data that can be null/undefined (API responses, params, optional relations)
- Error handling: try/catch around external calls with user-visible failure states — never silent `catch {}`
- Dates/timezones, currency math (no float money — use integers/decimal), off-by-one in pagination

## 3. Performance
- N+1 queries (loop with await inside → batch with `include`/`in`); missing DB indexes on filtered/sorted columns
- Server vs client components: data-fetching in server components; `"use client"` pushed to leaves, not slapped on pages
- Bundle: heavy libs dynamically imported (`next/dynamic`) when below-fold; images via `next/image`; fonts via `next/font`
- Re-render hotspots: expensive computation without memo, context that changes every render, objects/arrays created inline as props to memoized children
- Caching: appropriate `revalidate`/cache headers; no accidental `cache: 'no-store'` everywhere

## 4. Maintainability
- Dead code, unused imports/deps, commented-out blocks → delete
- Duplication: same logic in 3+ places → extract
- Components > ~200 lines or mixing data+presentation+logic → split
- Naming says what things ARE (no `data2`, `handleClick3`, `temp`)
- Types: no `any` (use `unknown` + narrowing); shared types in one place; API responses typed end to end
- Magic numbers/strings → named constants
- TODO/FIXME comments → convert to PROJECT_STATE.md issues or resolve

## 5. Hygiene
- `npm run build` clean; `tsc --noEmit` clean; ESLint clean or justified
- `.env.example` updated; README run instructions accurate
- No `console.log` left in production paths (proper logging or removed)

## Output
Findings table with severity + file:line + one-line fix recommendation. Cluster related findings (e.g., "validation missing in 6 routes" = one HIGH item with a list). Feed to gap-analysis.
