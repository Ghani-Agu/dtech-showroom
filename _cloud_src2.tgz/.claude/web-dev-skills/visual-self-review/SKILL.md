---
name: visual-self-review
description: Render and visually inspect the actual website using Playwright screenshots, then critique what is SEEN, not what the code says. MANDATORY during every review round of any project with a UI, and whenever judging design quality, layout, responsiveness, or "does it look good". Code review cannot catch visual problems — this skill is the only way to see the real output. Trigger on "review the design", "check how it looks", "is it responsive", or any review phase.
---

# Visual Self-Review

You cannot judge a website you have never seen. Reading JSX tells you what should render; only a screenshot tells you what does. This pass is mandatory every review round — no exceptions.

## Setup (once per project)

```bash
npm i -D playwright && npx playwright install chromium --with-deps
```

Screenshot script (save as `scripts/screenshot.mjs`):

```js
import { chromium } from 'playwright';
const routes = process.argv.slice(2).length ? process.argv.slice(2) : ['/'];
const viewports = [
  { name: 'mobile', width: 375, height: 812 },
  { name: 'tablet', width: 768, height: 1024 },
  { name: 'desktop', width: 1440, height: 900 },
];
const browser = await chromium.launch();
for (const vp of viewports) {
  const page = await browser.newPage({ viewport: { width: vp.width, height: vp.height } });
  const errors = [];
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', e => errors.push(e.message));
  for (const r of routes) {
    await page.goto(`http://localhost:3000${r}`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(800); // let entrance animations settle
    const slug = r === '/' ? 'home' : r.replace(/\//g, '_');
    await page.screenshot({ path: `screenshots/${slug}-${vp.name}.png`, fullPage: true });
    if (errors.length) console.log(`CONSOLE ERRORS ${r} @${vp.name}:`, errors);
    errors.length = 0;
  }
  await page.close();
}
await browser.close();
```

Run dev server in background, then: `node scripts/screenshot.mjs / /products /contact ...` for EVERY route. Also capture key states: open the mobile menu, open a modal, a filled form with errors, an empty state (use `page.click`/`page.fill` in a variant script when needed).

## The critique (look at every image, write findings)

View each screenshot file and judge it as a demanding client seeing the site for the first time:

**Layout & integrity**
- Anything overflowing, overlapping, cut off, or misaligned? Horizontal scrollbar on mobile?
- Spacing rhythm: do gaps between sections look consistent and intentional, or random?
- Images: stretched, squashed, wrong crop, broken (alt-text boxes)?

**Hierarchy & first impression (the 3-second test)**
- Within 3 seconds of looking: is it clear what this site is and what to do next?
- Is the visual hierarchy on the screenshot the same as the intended one? (What does your eye hit first? Is that the right thing?)

**Design quality (the agency test)**
- Would a design-literate person believe a professional studio made this page? If the honest answer is "it looks like a template/AI output", verdict = REDESIGN — name specifically why (flat hierarchy? timid type scale? evenly-spaced sameness? stock-feeling sections?)
- Compare against the art direction doc (see frontend-design-system): does the page deliver the stated feeling?

**Responsive truth**
- Mobile: nav usable? text readable without zoom? touch targets visibly large enough? hero still impactful or just shrunk desktop?
- Tablet: not just stretched mobile or squeezed desktop?

**Real content stress**
- Longest real strings (French/Arabic) — anything truncated or wrapping ugly?
- RTL builds: capture screenshots in BOTH directions; verify true mirroring in the image.

**Console errors** captured by the script = automatic findings.

## Output
Findings table (severity + route + viewport + what the screenshot shows + fix/redesign recommendation) → feed to gap-analysis. Keep the `screenshots/` folder per round (`screenshots/round-2/`) so before/after can be compared. In the final round, re-view every screenshot and confirm zero visual findings before exit criteria can be met.
