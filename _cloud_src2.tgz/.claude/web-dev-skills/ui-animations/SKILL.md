---
name: ui-animations
description: Motion design for web UIs — micro-interactions, page transitions, scroll animations, loading states, 3D effects, and particle systems. Use whenever the user mentions animations, transitions, motion, "make it feel alive/smooth/premium", hover effects, scroll effects, hero animations, 3D elements, Three.js, Framer Motion, or whenever building a landing page or marketing site (those always need motion polish even if not explicitly requested).
---

# UI Animations

## Tool selection

| Need | Use |
|---|---|
| Hover/focus/simple transitions | Pure CSS (`transition`, `transform`) — never JS for these |
| Enter/exit, layout, gestures, scroll-linked | Framer Motion (`motion/react`) |
| Complex timelines, SVG drawing | GSAP (only if Framer can't do it) |
| 3D scenes, particles | Three.js / React Three Fiber (`@react-three/fiber` + `drei`) |
| Number counters, simple scroll reveals | IntersectionObserver + CSS, no library |

## Principles

1. **Purpose over decoration.** Every animation answers: what does this communicate? (feedback, spatial continuity, attention, personality). If no answer → cut it.
2. **Fast and physical.** Micro-interactions 150–250ms; transitions 300–500ms; nothing over 800ms except intentional hero moments. Prefer spring physics (Framer default) over linear/ease-in.
3. **Animate cheap properties only**: `transform` and `opacity`. Never animate width/height/top/left/margin (layout thrash) — use `scale`/`translate`, or Framer's `layout` prop which FLIPs for you.
4. **Respect `prefers-reduced-motion`** — wrap non-essential motion:
```css
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
```
5. **Stagger lists** (40–80ms per item, cap visible delay ~600ms total).
6. **Don't block interaction.** Content must be readable/clickable before entrance animations finish; never gate the page behind a long intro.

## Standard patterns (copy-adapt)

**Scroll reveal (Framer):**
```tsx
<motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.5, ease: "easeOut" }} />
```

**Button micro-interaction (CSS only):** translateY(-1px) + slight shadow on hover, scale(0.98) on active, visible focus ring always.

**Page transitions (Next.js App Router):** `template.tsx` with a motion wrapper, fade+slide 300ms. Keep it subtle.

**Loading**: skeletons matching real layout (pulse via CSS), not spinners, for content areas. Spinners only for actions.

**3D particle sphere / hero scenes (R3F):**
- Points + BufferGeometry with Float32Array positions; animate in `useFrame`
- Cap particle count by device (`navigator.hardwareConcurrency`, mobile ≤ 2–3k points)
- `<Canvas dpr={[1, 1.75]} gl={{ antialias: false, powerPreference: "high-performance" }}>`
- Pause rendering when offscreen (`frameloop="demand"` + invalidate, or IntersectionObserver)
- Always provide a static fallback for reduced-motion and WebGL-unavailable

## Review checklist (when auditing motion in review rounds)
- Any jank? (Open dev tools performance; look for layout/paint in animation frames)
- Anything animating layout properties? → flag
- Reduced-motion respected?
- Entrance animations re-trigger annoyingly on scroll up/down? (`once: true`)
- Mobile: 3D/heavy effects throttled or replaced?
- Consistent easing/duration vocabulary across the app (define 2–3 named durations, reuse)
