---
name: web-app-architect
description: Architecture, planning, and stack decisions for web and web-app projects. Use this BEFORE writing code whenever starting a new web project, adding a major feature, restructuring an existing codebase, or deciding on stack/folder structure/data flow/state management. Triggers include "build a website/web app/SaaS/dashboard/landing page", "plan the project", "what structure should we use", or any greenfield development task.
---

# Web App Architect

## Default stack (override only if the project instructions say otherwise)

- **Framework**: Next.js (App Router) + TypeScript, strict mode
- **Styling**: Tailwind CSS (v4 syntax: `@import "tailwindcss"`, CSS-first config via `@theme`)
- **DB/ORM**: Prisma + Postgres (Supabase) when persistence is needed
- **Auth**: NextAuth/Auth.js or Supabase Auth
- **Validation**: Zod on every API boundary and form
- **Static sites / simple sites**: plain HTML+CSS+JS or Vite is fine — don't over-engineer a site vitrine into a Next.js monorepo

## Planning checklist (do this before coding)

1. **Extract requirements** — list every feature/page/behavior from instructions. Ambiguities: pick the sensible default, note the assumption in PROJECT_STATE.md, continue (don't stall waiting).
2. **Pages & routes map** — every route, its purpose, public/protected status
3. **Data model** — entities, relations, who can read/write what
4. **Component inventory** — shared components (layout, nav, cards, forms, modals) vs page-specific
5. **State plan** — server components by default; client state only where interaction demands it; React Query/SWR for server cache if app is data-heavy
6. **API surface** — route handlers / server actions, with auth + validation per endpoint

## Structure conventions

```
src/
  app/                 # routes (App Router)
  components/
    ui/                # dumb, reusable primitives
    [feature]/         # feature-specific components
  lib/                 # utils, db client, auth helpers, validators
  hooks/
  types/
```

- One component per file. Extract when a component passes ~150 lines or mixes concerns.
- Server-only code (db, secrets) never imported in client components — use `server-only` package guard.
- Environment: `.env.example` always committed; real `.env` never. Never print env contents.

## Decision rules

- **Multi-tenant**: tenant scoping in EVERY query (tenantId in where clause), never trust client-sent tenant IDs — derive from session.
- **i18n / RTL**: if Arabic is involved, plan `dir="rtl"` support from day one; use logical CSS properties (`ms-`, `me-`, `ps-`, `pe-` in Tailwind) instead of left/right.
- **Forms**: react-hook-form + Zod resolver for anything beyond 2 fields.
- **Fetching**: server components fetch directly; client mutations via server actions or API routes with optimistic UI only when it clearly helps.

## Output of this skill

A short written plan (in PROJECT_STATE.md or PLAN.md): routes map, data model, component inventory, and 3–7 build milestones in order. Then start building milestone 1.
