---
name: content-localization
description: Writing real website/app content and handling multilingual (Arabic/French/English) and RTL localization. Use whenever a project needs visible text — headlines, product copy, UI labels, error messages, empty states — and ALWAYS instead of lorem ipsum or placeholder text. Also use for i18n setup, RTL layout, Arabic typography, and bilingual MENA-market sites.
---

# Content & Localization

## Rule zero: no lorem ipsum, ever
Placeholder text hides layout bugs (real Arabic headlines are longer; real product names overflow) and makes design reviews meaningless. Write plausible real copy from the project's domain. If the user must supply final copy, write a realistic draft and mark it `<!-- DRAFT COPY - replace -->` + list it in PROJECT_STATE.md deferred items.

## Writing copy that works
- **Headlines**: concrete benefit, not slogan-vague. "Réponses automatiques à vos clients, 24h/24" beats "L'avenir de la communication".
- **CTAs**: verb + outcome ("Demander une démo", "Voir le catalogue") — never "Cliquez ici", "Submit", "En savoir plus" everywhere.
- **Microcopy**: errors say what happened + what to do; empty states explain + give the first action; confirmations state the consequence.
- **Tone**: B2B MENA = professional French/Arabic for product and technical terms; warmth sparingly. The user writes Algerian Darija HIMSELF — never generate Darija; leave marked slots: `<!-- DARIJA: owner writes this -->`.
- Numbers/currency: DZD formatted consistently (e.g., "45 000 DA"); dates in local convention; phone format +213.

## i18n architecture (Next.js)
- 2+ languages → `next-intl` (App Router native): locale segment `[locale]`, messages per locale JSON, `generateMetadata` localized too
- Keys by meaning not location (`cta.requestDemo` not `homepage.button3`); no string concatenation across keys (grammar differs); ICU plurals for counts (Arabic has 6 plural forms — use ICU, never `count + " items"`)
- Never hardcode visible strings in components once i18n exists — review rounds grep for raw text in JSX

## RTL correctness (beyond dir="rtl")
- `<html lang dir>` per locale; Tailwind logical utilities ONLY (`ms-`, `me-`, `ps-`, `pe-`, `start-`, `end-`, `text-start`) — grep-ban `ml-`, `mr-`, `pl-`, `pr-`, `left-`, `right-`, `text-left` in shared components
- Mirror directional icons (arrows, chevrons, back); do NOT mirror logos, media controls, clocks, phone numbers
- Numbers and Latin product codes stay LTR inside RTL text: `dir="ltr"` spans or `unicode-bidi`
- Mixed-direction strings (Arabic sentence + French brand name): test with real data; use `&lrm;`/`&rlm;` marks where punctuation jumps

## Arabic typography
- Fonts: IBM Plex Sans Arabic / Cairo / Tajawal for UI; Amiri for formal/traditional documents. Verify the Latin pair has matching weights.
- Arabic needs larger line-height (1.7-1.9) and often +1-2px size vs Latin equivalent; never letter-spacing on Arabic (breaks letter joining); no fake italic
- Test every component with the LONGEST locale's strings (usually French) and Arabic

## Review checklist (review rounds)
Any lorem ipsum or English leftovers in non-English locales? Truncation/overflow with real Arabic + French strings? RTL: full mirror, not just translated text? Vague CTAs? Inconsistent currency/date formats? Untranslated metadata/OG tags? Plurals correct at counts 0, 1, 2, 11?
