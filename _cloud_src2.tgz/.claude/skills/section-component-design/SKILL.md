---
name: section-component-design
description: >
  Use when building, restyling, or reviewing any editor section or component, or
  when implementing the hover help-cards. Defines the "so good, so simple" quality
  bar, the hover-card + micro-animation spec, theme-adaptivity, and RTL safety, so
  the 29 sections and 23 components look professional and are obvious to use.
---

# section-component-design — the quality bar

The brief from Ghani: sections and components must look **so good and so simple**,
the whole editor usable by anyone, and **on hover, a card appears explaining the
thing + a small animation showing how to use it.** This skill is the bar.

## Non-negotiable: theme-adaptive + RTL-safe
Every block must:
- Use `currentColor`, the site accent (`--cyan`), and `color-mix(...)` for colour
  — never hard-coded hex. It must recolour correctly across all 8 themes and
  light/dark automatically.
- Use **logical CSS properties** (`margin-inline`, `padding-inline`,
  `inset-inline-start`, `text-align: start`) so it mirrors correctly in `/ar`.
- Collapse responsively: 4→2→1 columns. Never overflow on mobile.
A block that looks right in `/fr` light but breaks in `/ar` dark is **not done**.

## The "simple & good-looking" rubric (judge every block against it)
1. **One clear job per block.** If a user can't tell what it's for in 2 seconds,
   redesign it, don't add a tooltip to explain a confusing block.
2. **Generous whitespace, calm hierarchy.** Eyebrow → title → body → action, with
   real spacing. No cramped cards.
3. **Consistent rhythm.** Shared radius (16px), shared spacing scale, shared type
   scale across all blocks — they must feel like one family.
4. **Restraint.** One accent, limited weights. "$50k site" reads as confident and
   quiet, not busy.
5. **Real defaults.** A freshly added block must look finished with placeholder
   content — never empty or broken before the user edits it.

## The hover help-card + animation (build this as a first-class feature)
When the user hovers a section row (Layers) or a component, show a small **help
card**:
- **Card content:** the block's name, a one-line "what it's for," and a tiny
  preview/thumbnail of the block.
- **Animation:** a short, looping micro-demo (2–4s) showing the core gesture for
  that block — e.g. "drag to reorder," "click text to edit," "＋ to add a
  component." Keep it lightweight (CSS/Lottie-style, not video).
- **Rules:** respect `prefers-reduced-motion` (static card, no animation when set).
  Position the card so it never covers what it describes. Dismiss on mouse-leave.
  Same content available on keyboard focus, not hover-only (accessibility).
- **Source of truth:** put each block's help text + demo metadata in
  `section-presets.ts` next to the preset, so adding a block automatically gives it
  a help-card. Do not scatter copy across components.

## Review workflow (used by design-reviewer)
1. Render the block on the live route (both locales, light + dark, one custom theme).
2. Screenshot each state.
3. Score against the rubric above; compare side-by-side with the reference sites
   (`linear.app, framer.com, stripe.com`).
4. Output specific, visual fixes ("title too tight at 26px, bump to 30px and add
   8px below the eyebrow"), not vague praise. Then the builder applies, and
   `verify-live` confirms.

## Reminder
Any user-facing Algerian Darija copy stays as `{{DARIJA: intent}}` — never write it.
