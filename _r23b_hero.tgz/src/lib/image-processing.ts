import 'server-only'
import sharp from 'sharp'

export type ImageVariant = 'card' | 'hero' | 'carousel' | 'logo'
export type ImageFormat = 'webp' | 'avif'

interface VariantSpec {
  width: number
  height: number
  fit: keyof sharp.FitEnum
  quality: {
    webp: number
    avif: number
  }
}

export const VARIANT_SPECS: Record<ImageVariant, VariantSpec> = {
  card: {
    width: 800,
    height: 600,
    fit: 'cover',
    quality: { webp: 82, avif: 60 },
  },
  hero: {
    width: 2400,
    height: 1350,
    fit: 'cover',
    quality: { webp: 85, avif: 65 },
  },
  carousel: {
    width: 1600,
    height: 1200,
    fit: 'cover',
    quality: { webp: 82, avif: 60 },
  },
  logo: {
    width: 600,
    height: 600,
    fit: 'contain',
    quality: { webp: 85, avif: 65 },
  },
}

export async function validateImage(buffer: Buffer): Promise<{
  format: string
  width: number
  height: number
  size: number
}> {
  const meta = await sharp(buffer).metadata()

  if (!meta.format || !meta.width || !meta.height) {
    throw new Error('Invalid image — could not read metadata')
  }

  const validFormats = ['jpeg', 'jpg', 'png', 'webp', 'avif', 'tiff']
  if (!validFormats.includes(meta.format)) {
    throw new Error(`Unsupported image format: ${meta.format}`)
  }

  if (meta.width < 400 || meta.height < 300) {
    throw new Error(
      `Image too small: ${meta.width}×${meta.height} (minimum 400×300)`
    )
  }

  if (buffer.length > 20 * 1024 * 1024) {
    throw new Error(
      `File too large: ${(buffer.length / 1024 / 1024).toFixed(1)}MB (max 20MB)`
    )
  }

  return {
    format: meta.format,
    width: meta.width,
    height: meta.height,
    size: buffer.length,
  }
}

export async function processVariant(
  sourceBuffer: Buffer,
  variant: ImageVariant,
  format: ImageFormat
): Promise<Buffer> {
  const spec = VARIANT_SPECS[variant]

  const isContain = spec.fit === 'contain'
  let pipeline = sharp(sourceBuffer).resize(spec.width, spec.height, {
    fit: spec.fit,
    position: isContain ? 'center' : 'attention',
    background: isContain
      ? { r: 0, g: 0, b: 0, alpha: 0 }
      : undefined,
    withoutEnlargement: false,
  })

  if (format === 'webp') {
    pipeline = pipeline.webp({
      quality: spec.quality.webp,
      effort: 4,
    })
  } else if (format === 'avif') {
    pipeline = pipeline.avif({
      quality: spec.quality.avif,
      effort: 4,
    })
  }

  return pipeline.toBuffer()
}

/* ═══════════════════════════════════════════════════════════════════════════
   ROUND 23b — homepage slider slides
   Every other variant above CROPS to a fixed shape. Hero slides must not: the
   band on the storefront sizes ITSELF to the slides (tallest one wins), so
   whatever aspect ratio Ghani exports is the aspect ratio the site adopts.
   `fit: 'inside'` + `withoutEnlargement` therefore only ever shrinks an
   oversized upload — a 1920 × 700 banner comes through untouched — and the
   real output size is handed back so it can be stored with the slide.
   ═══════════════════════════════════════════════════════════════════════════ */
export const HERO_SLIDE_MAX = { width: 2400, height: 1600 } as const

export async function processHeroSlide(
  sourceBuffer: Buffer,
  format: ImageFormat
): Promise<{ data: Buffer; width: number; height: number }> {
  let pipeline = sharp(sourceBuffer)
    // honour EXIF orientation BEFORE measuring, or a phone shot reports its
    // dimensions swapped and the band adopts a ratio nothing actually has
    .rotate()
    .resize({
      width: HERO_SLIDE_MAX.width,
      height: HERO_SLIDE_MAX.height,
      fit: 'inside',
      withoutEnlargement: true,
    })

  pipeline =
    format === 'avif'
      ? pipeline.avif({ quality: 66, effort: 4 })
      : pipeline.webp({ quality: 86, effort: 4 })

  const { data, info } = await pipeline.toBuffer({ resolveWithObject: true })
  return { data, width: info.width, height: info.height }
}
