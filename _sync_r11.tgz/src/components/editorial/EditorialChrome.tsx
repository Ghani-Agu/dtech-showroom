'use client'

/**
 * Éditorial chrome — floating glass pill nav (with dark/light tone flip
 * driven by the [data-band] sections under it), fullscreen numbered menu,
 * and the floating dark rounded footer.
 *
 * Nav behaviour ported from the design (and held to the lorolabs bar):
 *  - fixed centered pill, never hides on scroll;
 *  - tone flips between dark-glass and light-glass depending on the band
 *    currently under the pill (design chat: "dark sections tagged data-band,
 *    the nav flips correctly between light and dark");
 *  - WhatsApp / call / menu are always-visible round actions (conversion
 *    controls stay one tap away, as in the design).
 */

import { useEffect, useRef, useState } from 'react'
import { usePathname, Link } from '@/i18n/routing'
import { useEditorial } from './editorial-context'
import { useCart } from '@/lib/cart'
import { useFocusTrap } from '@/hooks/useFocusTrap'
import { BRAND_WHATSAPP } from '@/components/brand/brand-types'
import {
  EdArrowUpRight,
  EdCart,
  EdClose,
  EdMail,
  EdMenu,
  EdPhone,
  EdPin,
  EdWhatsApp,
} from './editorial-icons'

export const ED_PHONE_DISPLAY = '0560 99 05 06'
export const ED_PHONE_TEL = '+213560990506'
export const ED_SAV_DISPLAY = '0561 616 911'
export const ED_SAV_TEL = '+213561616911'
export const ED_EMAIL = 'contact@dtech.dz'
export const ED_WA_URL = `https://wa.me/${BRAND_WHATSAPP}`

/* ─────────────────────────── Header ─────────────────────────── */

function CartButton() {
  const { t } = useEditorial()
  const items = useCart((s) => s.items)
  const setOpen = useCart((s) => s.setOpen)
  const count = items.reduce((a, i) => a + i.qty, 0)
  return (
    <button className="ed-nav-icobtn" aria-label={t('aria.cart')} onClick={() => setOpen(true)}>
      <EdCart />
      {count > 0 ? <span className="ed-cartn">{count}</span> : null}
    </button>
  )
}

export function EditorialHeader() {
  const { t } = useEditorial()
  const pathname = usePathname()
  const onHome = pathname === '/'
  const [tone, setTone] = useState<'dark' | 'light'>(onHome ? 'dark' : 'light')
  const [menuOpen, setMenuOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const menuRef = useFocusTrap<HTMLDivElement>(menuOpen, () => setMenuOpen(false))

  /* Tone flip — the band under the pill decides the pill's glass. */
  useEffect(() => {
    let raf = 0
    const measure = () => {
      raf = 0
      const bands = document.querySelectorAll<HTMLElement>('.editorial-root [data-band]')
      if (!bands.length) return
      const probe = 58 // nav pill vertical center
      let current: HTMLElement | null = null
      for (const band of bands) {
        const r = band.getBoundingClientRect()
        if (r.top <= probe && r.bottom >= probe) current = band
      }
      const next =
        current?.dataset.band === 'dark' ? 'dark' : current ? 'light' : onHome ? 'dark' : 'light'
      setTone(next)
    }
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(measure)
    }
    measure()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [onHome, pathname])

  /* Menu: lock page scroll while open (focus trap handles Tab + Escape). */
  useEffect(() => {
    if (!menuOpen) return
    const prev = document.documentElement.style.overflow
    document.documentElement.style.overflow = 'hidden'
    return () => {
      document.documentElement.style.overflow = prev
    }
  }, [menuOpen])

  const links: { key: string; href: string; anchor?: string }[] = [
    { key: 'nav.home', href: '/' },
    { key: 'nav.catalogue', href: '/products', anchor: '#catalogue' },
    { key: 'nav.brands', href: '/brands', anchor: '#marques' },
    { key: 'nav.why', href: '/about', anchor: '#services' },
    { key: 'nav.ranges', href: '/categories', anchor: '#catalogue' },
    { key: 'nav.contact', href: '/about', anchor: '#contact' },
  ]

  const NavA = ({ l, children }: { l: (typeof links)[number]; children: React.ReactNode }) =>
    onHome && l.anchor ? (
      <a href={l.anchor}>{children}</a>
    ) : (
      <Link href={l.href}>{children}</Link>
    )

  return (
    <>
      <div className="ed-navwrap" data-tone={tone} ref={wrapRef}>
        <nav className="ed-nav" aria-label="Navigation">
          {onHome ? (
            <a href="#top" className="ed-nav-logo" aria-label="D-Tech">
              dt
            </a>
          ) : (
            <Link href="/" className="ed-nav-logo" aria-label="D-Tech">
              dt
            </Link>
          )}
          <div className="ed-nav-links">
            {links.map((l) => (
              <NavA key={l.key} l={l}>
                {t(l.key)}
              </NavA>
            ))}
          </div>
          <div className="ed-nav-acts">
            <a
              className="ed-nav-icobtn wa"
              href={ED_WA_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={t('aria.wa')}
            >
              <EdWhatsApp />
            </a>
            <a className="ed-nav-icobtn" href={`tel:${ED_PHONE_TEL}`} aria-label={t('aria.call')}>
              <EdPhone />
            </a>
            <CartButton />
            <button
              className="ed-nav-icobtn"
              aria-label={t('aria.menu')}
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen(true)}
            >
              <EdMenu />
            </button>
          </div>
        </nav>
      </div>

      {menuOpen ? (
        <div className="ed-menu" role="dialog" aria-modal="true" aria-label={t('menu.title')} ref={menuRef}>
          <button className="ed-menu-close" aria-label={t('aria.close')} onClick={() => setMenuOpen(false)}>
            <EdClose />
          </button>
          <ul className="ed-menu-list">
            {links.map((l, i) => (
              <li key={l.key}>
                <span className="ed-menu-num">0{i + 1}</span>
                {onHome && l.anchor ? (
                  <a href={l.anchor} onClick={() => setMenuOpen(false)}>
                    {t(l.key)}
                  </a>
                ) : (
                  <Link href={l.href} onClick={() => setMenuOpen(false)}>
                    {t(l.key)}
                  </Link>
                )}
              </li>
            ))}
          </ul>
          <div className="ed-menu-foot">
            <div className="contact">
              <a href={`mailto:${ED_EMAIL}`}>{ED_EMAIL}</a>
              <a href={`tel:${ED_PHONE_TEL}`}>{ED_PHONE_DISPLAY}</a>
            </div>
            <a className="ed-btn on-light" href={ED_WA_URL} target="_blank" rel="noopener noreferrer">
              {t('hero.cta2')} <EdArrowUpRight />
            </a>
          </div>
        </div>
      ) : null}
    </>
  )
}

/* ─────────────────────────── Footer ─────────────────────────── */

export function EditorialFooter() {
  const { t } = useEditorial()
  const year = new Date().getFullYear()
  return (
    <div className="ed-footer-outer">
      <footer className="ed-footer">
        <div className="ed-wrap">
          <div className="ed-footer-grid">
            <div>
              <span className="ed-footer-word">dtech</span>
              <p className="ed-footer-desc">{t('foot.desc')}</p>
            </div>
            <div>
              <h4>{t('foot.nav')}</h4>
              <ul>
                <li><Link href="/">{t('nav.home')}</Link></li>
                <li><Link href="/products">{t('nav.catalogue')}</Link></li>
                <li><Link href="/brands">{t('nav.brands')}</Link></li>
                <li><Link href="/about">{t('nav.why')}</Link></li>
              </ul>
            </div>
            <div>
              <h4>{t('foot.cat')}</h4>
              <ul>
                <li><Link href="/categories">{t('nav.ranges')}</Link></li>
                <li><Link href="/search">{t('aria.search')}</Link></li>
                <li><Link href="/legal">{t('foot.legal')}</Link></li>
              </ul>
            </div>
            <div>
              <h4>{t('foot.contact')}</h4>
              <div className="ed-footer-contact">
                <span>
                  <EdPin size={14} /> {t('contact.addr')}
                </span>
                <a href={`tel:${ED_PHONE_TEL}`}>
                  <EdPhone size={14} /> {ED_PHONE_DISPLAY}
                </a>
                <a href={`tel:${ED_SAV_TEL}`}>
                  {t('contact.sav')} · {ED_SAV_DISPLAY}
                </a>
                <a href={`mailto:${ED_EMAIL}`}>
                  <EdMail size={14} /> {ED_EMAIL}
                </a>
              </div>
            </div>
          </div>
          <div className="ed-footer-base">
            <span>© {year} D-Tech · {t('foot.rights')}</span>
            <span>{t('hero.meta')}</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
