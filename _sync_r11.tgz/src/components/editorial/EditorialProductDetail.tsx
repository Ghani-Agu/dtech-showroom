'use client'

/**
 * Éditorial product detail — rendered inside EditorialPageShell. Same data
 * contract as the Brand skin's detail (BrandProductDetailData), presented in
 * the editorial register: mono breadcrumbs, Comfortaa display title, spec
 * table as an editorial dl, shared gallery/reviews/sticky-buy components.
 */

import { useState } from 'react'
import { Link } from '@/i18n/routing'
import { useEditorial } from './editorial-context'
import { useTranslations } from 'next-intl'
import { ReviewsSection } from '@/components/showroom/ReviewsSection'
import { ProductGallery } from '@/components/product/ProductGallery'
import { StickyBuyBar } from '@/components/product/StickyBuyBar'
import { Carousel } from '@/components/showroom/Carousel'
import { useCart, WHATSAPP_NUMBER } from '@/lib/cart'
import type { BrandProduct } from '@/components/brand/brand-types'
import type { BrandProductDetailData } from '@/components/brand/BrandProductDetail'
import { EdCart, EdWhatsApp } from './editorial-icons'

const ADDED: Record<string, string> = {
  fr: 'Ajouté au panier',
  en: 'Added to cart',
  ar: 'أُضيف إلى السلة',
}
const SIMILAR: Record<string, string> = {
  fr: 'Produits similaires',
  en: 'Similar products',
  ar: 'منتجات مشابهة',
}
const PREV: Record<'fr' | 'en' | 'ar', string> = { fr: 'Précédent', en: 'Previous', ar: 'السابق' }
const NEXT: Record<'fr' | 'en' | 'ar', string> = { fr: 'Suivant', en: 'Next', ar: 'التالي' }

export function EditorialProductDetail({
  product,
  similar,
}: {
  product: BrandProductDetailData
  similar: BrandProduct[]
}) {
  const { t, lang } = useEditorial()
  const tSpec = useTranslations('products.specLabels')
  const add = useCart((s) => s.add)
  const openCart = useCart((s) => s.setOpen)
  const [added, setAdded] = useState(false)
  const paragraphs = product.description ? product.description.split('\n\n') : []
  const waHref = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    `Bonjour D-Tech, je suis intéressé par : ${product.name}`
  )}`

  const onAdd = () => {
    add({
      slug: product.slug,
      name: product.name,
      brand: product.brandName,
      image: product.image,
    })
    setAdded(true)
    window.setTimeout(() => {
      setAdded(false)
      openCart(true)
    }, 650)
  }

  const specLabel = (key: string): string => {
    try {
      const label = tSpec(key)
      return label.includes('specLabels') ? key : label
    } catch {
      return key
    }
  }

  return (
    <section className="ed-band ed-pdp" data-band="light">
      <div className="ed-wrap">
        <nav className="ed-pdp-kicker ed-reveal" data-revealed aria-label="Breadcrumb">
          <Link className="crumb" href="/products">
            {t('pdp.back')}
          </Link>
          <span className="crumb" aria-hidden>
            /
          </span>
          <Link className="crumb" href={`/categories/${product.catSlug}`}>
            {product.catName}
          </Link>
          <span className="crumb" aria-hidden>
            /
          </span>
          <Link className="crumb" href={`/brands/${product.brandSlug}`}>
            {product.brandName}
          </Link>
        </nav>

        <div className="ed-pdp-grid" style={{ marginTop: 24 }}>
          <div className="ed-pdp-media">
            <ProductGallery images={[product.image, ...(product.images ?? [])]} alt={product.name} />
          </div>

          <div>
            <h1 className="ed-display ed-h2 ed-pdp-title">{product.name}</h1>
            {product.tagline ? <p className="ed-pdp-tag">{product.tagline}</p> : null}

            <div className="ed-pdp-ctas">
              <a className="ed-btn wa" href={waHref} target="_blank" rel="noopener noreferrer">
                <EdWhatsApp size={16} /> {t('pdp.order')}
              </a>
              <button className="ed-btn on-light" onClick={onAdd}>
                <EdCart size={15} /> {added ? ADDED[lang] : t('pdp.addcart')}
              </button>
            </div>

            {paragraphs.length > 0 ? (
              <div className="ed-pdp-tag" style={{ marginTop: 26 }}>
                {paragraphs.map((p, i) => (
                  <p key={i} style={{ margin: i === 0 ? 0 : '12px 0 0' }}>
                    {p}
                  </p>
                ))}
              </div>
            ) : null}

            {product.customHtml ? (
              <div
                className="ed-pdp-tag sr-customhtml"
                style={{ marginTop: 20 }}
                dangerouslySetInnerHTML={{ __html: product.customHtml }}
              />
            ) : null}

            {product.specs && Object.keys(product.specs).length > 0 ? (
              <dl className="ed-pdp-specs">
                <span className="ed-eyebrow" style={{ display: 'block', padding: '18px 0 6px' }}>
                  {t('pdp.specs')}
                </span>
                {Object.entries(product.specs).map(([k, v]) => (
                  <div className="ed-spec-row" key={k}>
                    <dt>{specLabel(k)}</dt>
                    <dd>{Array.isArray(v) ? v.join(', ') : String(v)}</dd>
                  </div>
                ))}
              </dl>
            ) : null}
          </div>
        </div>

        {similar.length > 0 ? (
          <div style={{ marginTop: 'clamp(40px, 6vw, 72px)' }}>
            <h2 className="ed-display ed-h3" style={{ marginBottom: 18 }}>
              {SIMILAR[lang]}
            </h2>
            <Carousel prevLabel={PREV[lang]} nextLabel={NEXT[lang]}>
              {similar.slice(0, 12).map((p) => (
                <article className="ed-card" key={p.slug} style={{ width: 260, flex: 'none' }}>
                  <Link href={`/products/${p.slug}`} className="ed-card-imgbox" aria-hidden tabIndex={-1}>
                    {p.img ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.img} alt="" loading="lazy" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', padding: 12 }} />
                    ) : null}
                  </Link>
                  <div className="ed-card-body">
                    <span className="ed-card-kicker">
                      {p.brand} · {p.catName}
                    </span>
                    <Link href={`/products/${p.slug}`} className="ed-card-name">
                      {p.name}
                    </Link>
                    <span className="ed-card-spec">{p.spec}</span>
                  </div>
                </article>
              ))}
            </Carousel>
          </div>
        ) : null}

        <ReviewsSection slug={product.slug} />

        <StickyBuyBar
          slug={product.slug}
          name={product.name}
          brand={product.brandName}
          image={product.image}
        />
      </div>
    </section>
  )
}
