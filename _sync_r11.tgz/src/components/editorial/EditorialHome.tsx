'use client'

/**
 * EditorialHome — the Éditorial skin homepage: hero → families → featured →
 * brands marquee → engagements → contact, inside the shared chrome.
 * Fed by the same BrandData mapping the Brand skin uses (real catalogue).
 */

import { EditorialProvider } from './editorial-context'
import { EditorialHeader, EditorialFooter } from './EditorialChrome'
import { CartDrawer } from '@/components/showroom/CartDrawer'
import { FloatingCart } from '@/components/showroom/FloatingCart'
import {
  EdHero,
  EdFamilies,
  EdFeatured,
  EdBrands,
  EdServices,
  EdContact,
} from './EditorialSections'
import type { BrandData } from '@/components/brand/brand-types'

export function EditorialHome({ locale, data }: { locale: string; data: BrandData }) {
  return (
    <EditorialProvider locale={locale}>
      <EditorialHeader />
      <main id="main-content">
        <EdHero heroImage={data.heroImages[0] ?? null} />
        <EdFamilies data={data} />
        <EdFeatured data={data} />
        <EdBrands data={data} />
        <EdServices />
        <EdContact />
      </main>
      <EditorialFooter />
      <CartDrawer />
      <FloatingCart />
    </EditorialProvider>
  )
}
