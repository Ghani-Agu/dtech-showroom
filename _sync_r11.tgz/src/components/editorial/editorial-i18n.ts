/**
 * Éditorial skin strings — FR is canonical (copy from the Claude Design
 * project "D-Tech - Éditorial"); EN mirrors it; AR is Modern Standard
 * Arabic written for this skin (flag to Ghani for review before launch).
 */

export type EdLang = 'fr' | 'en' | 'ar'

export const ED_TR: Record<EdLang, Record<string, string>> = {
  fr: {
    'nav.home': 'Accueil',
    'nav.catalogue': 'Catalogue',
    'nav.brands': 'Marques',
    'nav.why': 'Pourquoi dtech',
    'nav.ranges': 'Gammes',
    'nav.contact': 'Contact',
    'aria.menu': 'Ouvrir le menu',
    'aria.close': 'Fermer',
    'aria.cart': 'Panier',
    'aria.call': 'Nous appeler',
    'aria.wa': 'Commander sur WhatsApp',
    'aria.search': 'Rechercher',

    'hero.mark': 'D-tech.',
    'hero.title': "L'informatique qui tient ses promesses.",
    'hero.lede':
      'Ordinateurs, tablettes, imprimantes et réseau — sourcés chez HP, Dell, Lenovo, Canon et Epson, livrés partout en Algérie avec garantie et SAV assurés à Alger.',
    'hero.meta': 'Digital technologie · Alger · Depuis 2014',
    'hero.cta1': 'Voir le catalogue',
    'hero.cta2': 'Demander un devis',

    'fam.eyebrow': 'Catalogue',
    'fam.title': 'familles, un seul interlocuteur.',
    'fam.lede':
      "Nous sourçons, configurons et livrons — vous n'avez qu'un numéro à composer, avant comme après l'achat.",
    'fam.products': 'produits',

    'feat.eyebrow': 'Sélection',
    'feat.title': 'Le meilleur du moment.',
    'feat.lede': 'Une sélection courte, tenue à jour par l’équipe — le reste vit dans le catalogue.',
    'feat.viewall': 'Tout le catalogue',
    'feat.flag': 'Coup de cœur',
    'feat.order': 'Voir la fiche',

    'brands.eyebrow': 'Marques',
    'brands.title': 'Les constructeurs que nous représentons.',

    'svc.eyebrow': 'Engagements',
    'svc.title': 'Avant, pendant, après.',
    'svc.1.name': 'Conseil réel',
    'svc.1.desc': 'Un interlocuteur technique qui comprend votre besoin avant de vendre.',
    'svc.2.name': 'Stock à Alger',
    'svc.2.desc': 'Les produits affichés existent — retrait à Bab Ezzouar ou livraison 58 wilayas.',
    'svc.3.name': 'Garantie & SAV',
    'svc.3.desc': 'Service après-vente assuré par notre atelier, pas par une hotline lointaine.',
    'svc.4.name': 'Devis en 24h',
    'svc.4.desc': 'Entreprises et institutions : devis chiffré sous 24 heures ouvrées.',

    'banner.title': 'Un besoin spécifique ?',
    'banner.lede': 'Parc informatique, marché public, configuration sur mesure — parlons-en.',

    'contact.eyebrow': 'Contact',
    'contact.title': 'Passez nous voir, ou écrivez-nous.',
    'contact.lede': 'Showroom à Bab Ezzouar, Alger — ou une réponse rapide sur WhatsApp.',
    'contact.call': 'Appeler le magasin',
    'contact.sav': 'SAV',
    'contact.wa': 'Écrire sur WhatsApp',
    'contact.mail': 'Envoyer un e-mail',
    'contact.addr': 'Bab Ezzouar, Alger',
    'contact.note': 'Réponse sous 24h ouvrées',

    'foot.desc': "Matériel informatique authentique, garanti et suivi — pour les particuliers, les entreprises et les institutions en Algérie.",
    'foot.nav': 'Navigation',
    'foot.cat': 'Catalogue',
    'foot.contact': 'Studio & contact',
    'foot.legal': 'Mentions légales',
    'foot.rights': 'Tous droits réservés.',

    'pdp.order': 'Commander sur WhatsApp',
    'pdp.addcart': 'Ajouter au panier',
    'pdp.specs': 'Caractéristiques',
    'pdp.back': 'Catalogue',

    'menu.title': 'Menu',
  },

  en: {
    'nav.home': 'Home',
    'nav.catalogue': 'Catalogue',
    'nav.brands': 'Brands',
    'nav.why': 'Why dtech',
    'nav.ranges': 'Ranges',
    'nav.contact': 'Contact',
    'aria.menu': 'Open menu',
    'aria.close': 'Close',
    'aria.cart': 'Cart',
    'aria.call': 'Call us',
    'aria.wa': 'Order on WhatsApp',
    'aria.search': 'Search',

    'hero.mark': 'D-tech.',
    'hero.title': 'Technology that keeps its promises.',
    'hero.lede':
      'Computers, tablets, printers and networking — sourced from HP, Dell, Lenovo, Canon and Epson, delivered across Algeria with warranty and after-sales service in Algiers.',
    'hero.meta': 'Digital technology · Algiers · Since 2014',
    'hero.cta1': 'Browse the catalogue',
    'hero.cta2': 'Request a quote',

    'fam.eyebrow': 'Catalogue',
    'fam.title': 'families, one point of contact.',
    'fam.lede':
      'We source, configure and deliver — one number to call, before and after the purchase.',
    'fam.products': 'products',

    'feat.eyebrow': 'Selection',
    'feat.title': 'The best right now.',
    'feat.lede': 'A short list, curated by the team — everything else lives in the catalogue.',
    'feat.viewall': 'Full catalogue',
    'feat.flag': 'Team pick',
    'feat.order': 'View product',

    'brands.eyebrow': 'Brands',
    'brands.title': 'The manufacturers we represent.',

    'svc.eyebrow': 'Commitments',
    'svc.title': 'Before, during, after.',
    'svc.1.name': 'Real advice',
    'svc.1.desc': 'A technical contact who understands your need before selling.',
    'svc.2.name': 'Stock in Algiers',
    'svc.2.desc': 'Listed products exist — pickup in Bab Ezzouar or delivery to 58 wilayas.',
    'svc.3.name': 'Warranty & service',
    'svc.3.desc': 'After-sales handled by our own workshop, not a distant hotline.',
    'svc.4.name': 'Quotes in 24h',
    'svc.4.desc': 'Companies and institutions: a costed quote within 24 working hours.',

    'banner.title': 'Something specific?',
    'banner.lede': 'IT fleet, public tender, custom configuration — let’s talk.',

    'contact.eyebrow': 'Contact',
    'contact.title': 'Drop by, or write to us.',
    'contact.lede': 'Showroom in Bab Ezzouar, Algiers — or a fast reply on WhatsApp.',
    'contact.call': 'Call the store',
    'contact.sav': 'After-sales',
    'contact.wa': 'Write on WhatsApp',
    'contact.mail': 'Send an e-mail',
    'contact.addr': 'Bab Ezzouar, Algiers',
    'contact.note': 'Reply within 24 working hours',

    'foot.desc': 'Genuine, warrantied and supported IT equipment — for individuals, companies and institutions in Algeria.',
    'foot.nav': 'Navigation',
    'foot.cat': 'Catalogue',
    'foot.contact': 'Studio & contact',
    'foot.legal': 'Legal notice',
    'foot.rights': 'All rights reserved.',

    'pdp.order': 'Order on WhatsApp',
    'pdp.addcart': 'Add to cart',
    'pdp.specs': 'Specifications',
    'pdp.back': 'Catalogue',

    'menu.title': 'Menu',
  },

  ar: {
    'nav.home': 'الرئيسية',
    'nav.catalogue': 'الكتالوج',
    'nav.brands': 'العلامات',
    'nav.why': 'لماذا دي-تك',
    'nav.ranges': 'الفئات',
    'nav.contact': 'اتصل بنا',
    'aria.menu': 'فتح القائمة',
    'aria.close': 'إغلاق',
    'aria.cart': 'السلة',
    'aria.call': 'اتصل بنا',
    'aria.wa': 'اطلب عبر واتساب',
    'aria.search': 'بحث',

    'hero.mark': 'D-tech.',
    'hero.title': 'تقنيةٌ تفي بوعودها.',
    'hero.lede':
      'حواسيب وأجهزة لوحية وطابعات وشبكات — من HP وDell وLenovo وCanon وEpson، مع التوصيل إلى كل الجزائر وضمانٍ وخدمة ما بعد البيع في العاصمة.',
    'hero.meta': 'التقنية الرقمية · الجزائر · منذ 2014',
    'hero.cta1': 'تصفّح الكتالوج',
    'hero.cta2': 'اطلب عرض سعر',

    'fam.eyebrow': 'الكتالوج',
    'fam.title': 'عائلة منتجات، ومحاورٌ واحد.',
    'fam.lede': 'نحن نوفّر، نجهّز ونوصّل — رقمٌ واحد تتصل به، قبل الشراء وبعده.',
    'fam.products': 'منتجات',

    'feat.eyebrow': 'مختاراتنا',
    'feat.title': 'أفضل ما لدينا الآن.',
    'feat.lede': 'قائمة قصيرة يحدّثها الفريق باستمرار — والبقية في الكتالوج.',
    'feat.viewall': 'الكتالوج الكامل',
    'feat.flag': 'اختيار الفريق',
    'feat.order': 'عرض المنتج',

    'brands.eyebrow': 'العلامات',
    'brands.title': 'الشركات المصنّعة التي نمثّلها.',

    'svc.eyebrow': 'التزاماتنا',
    'svc.title': 'قبل البيع، وأثناءه، وبعده.',
    'svc.1.name': 'نصيحة حقيقية',
    'svc.1.desc': 'محاور تقني يفهم حاجتك قبل أن يبيعك.',
    'svc.2.name': 'مخزون في الجزائر',
    'svc.2.desc': 'المنتجات المعروضة متوفرة فعلاً — استلام من باب الزوار أو توصيل إلى 58 ولاية.',
    'svc.3.name': 'ضمان وخدمة ما بعد البيع',
    'svc.3.desc': 'خدمة ما بعد البيع تتم في ورشتنا، لا عبر خط هاتفي بعيد.',
    'svc.4.name': 'عرض سعر خلال 24 ساعة',
    'svc.4.desc': 'للشركات والمؤسسات: عرض سعر مفصّل خلال 24 ساعة عمل.',

    'banner.title': 'لديك طلب خاص؟',
    'banner.lede': 'حظيرة معلوماتية، صفقة عمومية، تجهيز مخصص — لنتحدث.',

    'contact.eyebrow': 'اتصل بنا',
    'contact.title': 'زُرنا، أو راسلنا.',
    'contact.lede': 'صالة العرض في باب الزوار، الجزائر — أو ردٌ سريع عبر واتساب.',
    'contact.call': 'اتصل بالمتجر',
    'contact.sav': 'خدمة ما بعد البيع',
    'contact.wa': 'راسلنا على واتساب',
    'contact.mail': 'أرسل بريدًا إلكترونيًا',
    'contact.addr': 'باب الزوار، الجزائر',
    'contact.note': 'ردّ خلال 24 ساعة عمل',

    'foot.desc': 'عتاد معلوماتي أصلي، مضمون ومتابَع — للأفراد والشركات والمؤسسات في الجزائر.',
    'foot.nav': 'التنقل',
    'foot.cat': 'الكتالوج',
    'foot.contact': 'العنوان والتواصل',
    'foot.legal': 'إشعار قانوني',
    'foot.rights': 'جميع الحقوق محفوظة.',

    'pdp.order': 'اطلب عبر واتساب',
    'pdp.addcart': 'أضف إلى السلة',
    'pdp.specs': 'المواصفات',
    'pdp.back': 'الكتالوج',

    'menu.title': 'القائمة',
  },
}

export function edT(lang: EdLang, key: string): string {
  return ED_TR[lang][key] ?? ED_TR.fr[key] ?? key
}
