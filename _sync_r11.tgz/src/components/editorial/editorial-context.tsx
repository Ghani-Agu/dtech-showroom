'use client'

/**
 * EditorialProvider — `.editorial-root` wrapper for the Éditorial skin.
 *
 * - Carries lang/dir from the route locale (next-intl) for the scoped CSS.
 * - Owns the skin's motion plumbing:
 *     · adds `.ed-motion` on mount (so no-JS/SSR renders everything visible),
 *     · one IntersectionObserver marks `.ed-reveal` elements `data-revealed`
 *       (the lorolabs recipe: reveal once, never un-reveal),
 *     · honours prefers-reduced-motion by revealing everything immediately.
 * - No theme toggle: the Éditorial design is band-based (dark hero, light
 *   sections), not user-switchable.
 *
 * All CSS is namespaced under `.editorial-root`, so nothing leaks into the
 * classic skin, the brand skin, or the admin.
 */

import '@/styles/editorial-design.css'
import { createContext, useContext, useEffect, useMemo, useRef, type ReactNode } from 'react'
import { edT, type EdLang } from './editorial-i18n'

interface EdCtxValue {
  lang: EdLang
  dir: 'ltr' | 'rtl'
  t: (key: string) => string
}

const EdCtx = createContext<EdCtxValue | null>(null)

export function useEditorial(): EdCtxValue {
  const ctx = useContext(EdCtx)
  if (!ctx) throw new Error('useEditorial must be used inside <EditorialProvider>')
  return ctx
}

export function EditorialProvider({
  locale,
  children,
}: {
  locale: string
  children: ReactNode
}) {
  const lang = (['fr', 'en', 'ar'].includes(locale) ? locale : 'fr') as EdLang
  const dir = lang === 'ar' ? 'rtl' : 'ltr'
  const rootRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const root = rootRef.current
    if (!root) return

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    root.classList.add('ed-motion')

    const targets = root.querySelectorAll<HTMLElement>('.ed-reveal')
    if (reduced || typeof IntersectionObserver === 'undefined') {
      targets.forEach((el) => el.setAttribute('data-revealed', ''))
      return
    }

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.setAttribute('data-revealed', '')
            io.unobserve(entry.target)
          }
        }
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.12 }
    )
    targets.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  const value = useMemo<EdCtxValue>(
    () => ({ lang, dir, t: (k: string) => edT(lang, k) }),
    [lang, dir]
  )

  return (
    <EdCtx.Provider value={value}>
      <div ref={rootRef} className="editorial-root" lang={lang} dir={dir}>
        {children}
      </div>
    </EdCtx.Provider>
  )
}
