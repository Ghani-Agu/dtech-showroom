'use client'

/**
 * Éditorial homepage sections — hero, families index, featured selection,
 * brands marquee, engagements, banner, contact. All data comes from the
 * real catalogue (BrandData shape — the same server mapping the Brand skin
 * uses), so the section content is live, never mocked.
 */

import Image from 'next/image'
import { Link } from '@/i18n/routing'
import { useEditorial } from './editorial-context'
import { useCart, WHATSAPP_NUMBER } from '@/lib/cart'
import type { BrandData, BrandProduct } from '@/components/brand/brand-types'
import {
  EdArrowRight,
  EdArrowUpRight,
  EdBox,
  EdCart,
  EdClock,
  EdMail,
  EdPhone,
  EdPin,
  EdShield,
  EdSparkle,
  EdWhatsApp,
  EdWrench,
} from './editorial-icons'
import {
  ED_EMAIL,
  ED_PHONE_DISPLAY,
  ED_PHONE_TEL,
  ED_SAV_DISPLAY,
  ED_SAV_TEL,
  ED_WA_URL,
} from './EditorialChrome'

/* ─────────────────────────── Hero ─────────────────────────── */

export function EdHero({ heroImage }: { heroImage: string | null }) {
  const { t } = useEditorial()
  return (
    <section className="ed-band ed-hero" data-band="dark" id="top">
      {heroImage ? (
        <div className="ed-hero-img" aria-hidden>
          {/* real hero-config slide when one is uploaded */}
          <Image src={heroImage} alt="" fill sizes="44vw" style={{ objectFit: 'cover' }} />
        </div>
      ) : null}
      <span className="ed-sparkle" style={{ top: '38%', insetInlineEnd: '38%' }} aria-hidden>
        <EdSparkle />
      </span>
      <div className="ed-wrap">
        <span className="ed-hero-mark ed-reveal" data-revealed>
          {t('hero.mark')}
        </span>
        <h1 className="ed-display ed-h1 ed-hero-title">{t('hero.title')}</h1>
        <p className="ed-lede ed-hero-lede">{t('hero.lede')}</p>
        <p className="ed-eyebrow ed-hero-meta">{t('hero.meta')}</p>
        <div className="ed-hero-ctas">
          <Link className="ed-btn on-dark" href="/products">
            {t('hero.cta1')} <EdArrowRight />
          </Link>
          <a className="ed-btn ghost-dark" href={ED_WA_URL} target="_blank" rel="noopener noreferrer">
            <EdWhatsApp size={16} /> {t('hero.cta2')}
          </a>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────── Families (categories index) ─────────────────── */

export function EdFamilies({ data }: { data: BrandData }) {
  const { t } = useEditorial()
  return (
    <section className="ed-band" data-band="light" id="catalogue">
      <div className="ed-wrap ed-inner-pad" style={{ paddingBlock: 'clamp(56px, 8vw, 110px)' }}>
        <div className="ed-sechead ed-reveal">
          <span className="ed-eyebrow">{t('fam.eyebrow')}</span>
          <h2 className="ed-display ed-h2">
            {data.categories.length} {t('fam.title')}
          </h2>
          <p className="ed-lede">{t('fam.lede')}</p>
        </div>
        <div className="ed-reveal">
          <div className="ed-fam-grid ed-stagger">
            {data.categories.map((c, i) => (
              <Link className="ed-fam-card" href={`/categories/${c.id}`} key={c.id}>
                <span className="ed-fam-num">{String(i + 1).padStart(2, '0')}</span>
                <span className="ed-fam-name">{c.name}</span>
                <span className="ed-fam-count">
                  {c.count} {t('fam.products')}
                </span>
                <span className="ed-fam-go">
                  <EdArrowRight />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────── Featured products ─────────────────── */

export function EdProductCard({ p, star }: { p: BrandProduct; star: boolean }) {
  const { t } = useEditorial()
  const add = useCart((s) => s.add)
  const waHref = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    `Bonjour D-Tech, je suis intéressé par : ${p.name}`
  )}`
  return (
    <article className={star ? 'ed-card is-star' : 'ed-card'}>
      {star ? <span className="ed-card-flag">{t('feat.flag')}</span> : null}
      <Link href={`/products/${p.slug}`} className="ed-card-imgbox" aria-hidden tabIndex={-1}>
        {p.img ? (
          <Image src={p.img} alt="" fill sizes="(max-width: 640px) 90vw, 300px" />
        ) : null}
      </Link>
      <div className="ed-card-body">
        <span className="ed-card-kicker">
          {p.brand} · {p.catName}
        </span>
        <Link href={`/products/${p.slug}`} className="ed-card-name">
          {p.name}
        </Link>
        <span className="ed-card-spec">{p.spec}</span>
        <div className="ed-card-foot">
          <Link className="ed-card-cta" href={`/products/${p.slug}`}>
            {t('feat.order')}
          </Link>
          <button
            className="ed-card-wa"
            aria-label={t('aria.cart')}
            onClick={() => add({ slug: p.slug, name: p.name, brand: p.brand, image: p.img ?? '' })}
          >
            <EdCart size={15} />
          </button>
          <a
            className="ed-card-wa"
            href={waHref}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={t('aria.wa')}
          >
            <EdWhatsApp size={15} />
          </a>
        </div>
      </div>
    </article>
  )
}

export function EdFeatured({ data }: { data: BrandData }) {
  const { t } = useEditorial()
  return (
    <section className="ed-band" data-band="light-alt" id="selection">
      <div className="ed-wrap" style={{ paddingBlock: 'clamp(56px, 8vw, 110px)' }}>
        <div className="ed-sechead ed-reveal" style={{ gridTemplateColumns: '1fr auto', alignItems: 'end', display: 'grid' }}>
          <div style={{ display: 'grid', gap: 14 }}>
            <span className="ed-eyebrow">{t('feat.eyebrow')}</span>
            <h2 className="ed-display ed-h2">{t('feat.title')}</h2>
            <p className="ed-lede">{t('feat.lede')}</p>
          </div>
          <Link className="ed-btn on-light" href="/products">
            {t('feat.viewall')} <EdArrowRight />
          </Link>
        </div>
        <div className="ed-reveal">
          <div className="ed-prod-grid ed-stagger">
            {data.products.map((p, i) => (
              <EdProductCard p={p} star={i === 0} key={p.slug} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────── Brands marquee ─────────────────── */

export function EdBrands({ data }: { data: BrandData }) {
  const { t } = useEditorial()
  const items = data.brands.filter((b) => b.count > 0)
  const loop = [...items, ...items]
  return (
    <section className="ed-band" data-band="dark" id="marques">
      <div className="ed-wrap" style={{ paddingBlock: 'clamp(52px, 7vw, 96px)' }}>
        <div className="ed-sechead ed-reveal">
          <span className="ed-eyebrow">{t('brands.eyebrow')}</span>
          <h2 className="ed-display ed-h2">{t('brands.title')}</h2>
        </div>
      </div>
      <div className="ed-marquee ed-reveal" style={{ paddingBottom: 'clamp(52px, 7vw, 96px)' }}>
        <div className="ed-marquee-track">
          {loop.map((b, i) => (
            <Link
              className="ed-marquee-item"
              href={`/brands/${b.id}`}
              key={`${b.id}-${i}`}
              aria-hidden={i >= items.length || undefined}
              tabIndex={i >= items.length ? -1 : undefined}
            >
              {b.name}
              <span className="n">{b.count}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─────────────────── Engagements / services ─────────────────── */

const SVC_ICONS = [EdBox, EdPin, EdShield, EdClock] as const

export function EdServices() {
  const { t } = useEditorial()
  return (
    <section className="ed-band" data-band="light" id="services">
      <div className="ed-wrap" style={{ paddingBlock: 'clamp(56px, 8vw, 110px)' }}>
        <div className="ed-sechead ed-reveal">
          <span className="ed-eyebrow">{t('svc.eyebrow')}</span>
          <h2 className="ed-display ed-h2">{t('svc.title')}</h2>
        </div>
        <div className="ed-reveal">
          <div className="ed-svc-grid ed-stagger">
            {[1, 2, 3, 4].map((n, i) => {
              const Ico = SVC_ICONS[i] ?? EdWrench
              return (
                <div className="ed-svc" key={n}>
                  <span className="ed-svc-ico">
                    <Ico />
                  </span>
                  <span className="ed-svc-name">{t(`svc.${n}.name`)}</span>
                  <span className="ed-svc-desc">{t(`svc.${n}.desc`)}</span>
                </div>
              )
            })}
          </div>
        </div>
        <div className="ed-reveal" style={{ marginTop: 'clamp(20px, 3vw, 34px)' }}>
          <a className="ed-banner" href={ED_WA_URL} target="_blank" rel="noopener noreferrer">
            <div>
              <h3>{t('banner.title')}</h3>
              <p>{t('banner.lede')}</p>
            </div>
            <span className="ed-banner-go">
              <EdArrowUpRight size={20} />
            </span>
          </a>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────── Contact ─────────────────── */

export function EdContact() {
  const { t } = useEditorial()
  return (
    <section className="ed-band" data-band="light-alt" id="contact">
      <div className="ed-wrap" style={{ paddingBlock: 'clamp(56px, 8vw, 110px)' }}>
        <div className="ed-contact-grid">
          <div className="ed-sechead ed-reveal" style={{ marginBottom: 0 }}>
            <span className="ed-eyebrow">{t('contact.eyebrow')}</span>
            <h2 className="ed-display ed-h2">{t('contact.title')}</h2>
            <p className="ed-lede">{t('contact.lede')}</p>
            <span className="ed-contact-note">{t('contact.note')}</span>
          </div>
          <div className="ed-contact-card ed-reveal">
            <a className="ed-contact-row" href={`tel:${ED_PHONE_TEL}`}>
              <span className="ico">
                <EdPhone />
              </span>
              {t('contact.call')} · {ED_PHONE_DISPLAY}
            </a>
            <a className="ed-contact-row" href={`tel:${ED_SAV_TEL}`}>
              <span className="ico">
                <EdWrench size={17} />
              </span>
              {t('contact.sav')} · {ED_SAV_DISPLAY}
            </a>
            <a className="ed-contact-row" href={ED_WA_URL} target="_blank" rel="noopener noreferrer">
              <span className="ico">
                <EdWhatsApp size={17} />
              </span>
              {t('contact.wa')}
            </a>
            <a className="ed-contact-row" href={`mailto:${ED_EMAIL}`}>
              <span className="ico">
                <EdMail />
              </span>
              {ED_EMAIL}
            </a>
            <span className="ed-contact-row" style={{ cursor: 'default' }}>
              <span className="ico">
                <EdPin />
              </span>
              {t('contact.addr')}
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
