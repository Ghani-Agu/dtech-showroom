---
name: verify-live
description: >
  Use this BEFORE claiming any editor change is done, and after every save/publish.
  Defines the mandatory protocol to prove a change actually reached the real site:
  build, log in, edit, publish, reload the LIVE route fresh, screenshot, confirm.
  Load this constantly — it is the rule that stops the project from looping.
---

# verify-live — proof, not vibes

A change is **done only when seen live**. This skill is the proof procedure.
If you cannot complete it, the change is NOT done — say so and stop. Do not guess.

## Why this exists
Past attempts looped for weeks because the agent edited blind: stale sandbox
files + a logged-out editor meant it never actually saw whether a change reached
the real site. This protocol removes the blindness.

## The gate — run EVERY time you change editor behavior or content

1. **Re-read fresh.** Re-open the file(s) you are about to touch from disk. Do not
   trust any earlier copy in context (sandbox mounts go stale on large files).
2. **Authoritative build.** Run the real build (`__BUILD_CMD__`, e.g.
   `npm run build`) on the real environment. **Ignore sandbox typecheck** — it
   produces false errors on large files. If the real build fails, fix that first.
3. **Start the dev server** (`__DEV_CMD__`) → `http://localhost:3000`.
4. **Log in.** Go to `/login`, authenticate with the editor account
   (`__LOGIN_METHOD__`). Confirm `/editor` loads and does NOT redirect to `/login`.
   If it redirects, STOP — you cannot verify; tell the human the session is dead.
5. **Make the change in the editor** on `/<locale>?edit=1` (do it the way a user
   would — click/drag/inspect), then **Enregistrer** and **Publier**.
6. **THE PROOF: open `/<locale>` in a FRESH tab** — the public route, NOT the
   `?edit=1` iframe. Hard-reload. Confirm the change is present.
7. **Screenshot** the live route showing the change. Attach it to your result.
8. **Both locales.** Repeat the live check on `/ar` (RTL). A change that works in
   `/fr` but breaks in `/ar` is a failed verification, not a pass.
9. **Round-trip the store.** Confirm the change persisted to the published copy:
   reload `/fr` once more in a clean session — it must survive a fresh load
   (proves it hit the published `content:<pageKey>` row, not just draft state).

## Pass / fail
- **PASS** = the change is visible on the public `/fr` AND `/ar` after a fresh
  load, with screenshots, and survives a clean reload.
- **FAIL** = anything else. On fail: do NOT patch on top. Revert (see
  `no-loop-protocol`) and re-diagnose.

## What you report back to the lead
```
CHANGE: <one line>
BUILD: pass/fail (authoritative)   LOGIN: ok/redirect
LIVE /fr: seen/not   LIVE /ar: seen/not   PERSIST after reload: yes/no
SCREENSHOTS: <paths>
VERDICT: DONE / NOT DONE — <reason if not>
```

Never write "should now work" or "this likely fixes it." Either it is DONE with a
screenshot, or it is NOT DONE.
