---
name: theme-system
description: >
  Use when working on themes, the theme picker, or anything that changes the site
  palette. Explains the 8 themes, how a theme reaches the real site
  (body[data-site-theme] + site-themes.css driven by published content), the bug
  that was already fixed, and how to avoid regressing it.
---

# theme-system — palettes that actually reach the live site

Themes change the whole site's palette while keeping content. There are 8:
**Nightline** (default, dark mint) · **Méditerranée éditoriale** (light ivoire/
cobalt) · **Onyx & Or** (dark charbon/or) · **Studio Solaire** (light papier/
corail) · **Noir Éditorial** (light blanc/encre/rouge) · **Botanique** (light
crème/vert/terracotta) · **Aurore** (light blush/prune/pervenche) · **Cyber Néon**
(dark indigo/cyan/magenta).

## How a theme reaches the real site (the correct path)
```
/editor/themes → "Appliquer"
   → setContentTheme stores theme on the page content (published)
   → live site reads it via getSiteTheme (editor-page-data.ts)
   → root emits  body[data-site-theme="<theme>"]
   → site-themes.css supplies the real per-theme palette variables
   → /fr and /ar restyle immediately (global, all locales)
```

## The bug that was already fixed — DO NOT regress it
Previously "Appliquer" only restyled the theme **preview** and not the real site,
because the theme was saved to **a store the live site never read**, and the real
pages had **no per-theme variants**. The fix: theme stored on page content, emitted
as `body[data-site-theme]`, backed by real palettes in `site-themes.css`.

> Rule: a new theme or theme control is not done until applying it visibly changes
> `/fr` AND `/ar` on a fresh public load (verify-live confirms with screenshots,
> e.g. Onyx turns the background to charbon with gold accents; switching back to
> Nightline restores dark mint). If the preview changes but the live route doesn't,
> you've re-created the original bug.

## Known interactions to respect
- For non-Nightline themes, **the theme owns light/dark mode** (it sets the mode on
  load), so the manual toggle is overridden on reload when a custom theme is active.
  Don't "fix" this without deciding the intended behavior with Ghani first.
- Theme is **global** (driven by the home page's published content), not per page.
  Per-page themes are a possible future feature, not a default.
- A new theme must define BOTH its palette in `site-themes.css` and its entry in
  `themes.ts` (the 8 definitions). Adding one without the other half-wires it.

## Adding/altering a theme — checklist
1. Add palette variables to `site-themes.css` (cover light/dark + accent + RTL).
2. Add/adjust the definition in `themes.ts`.
3. Confirm every component recolours via `currentColor`/accent/`color-mix`
   (see `section-component-design`) — no hard-coded colours leaking through.
4. Apply it, then `verify-live` on `/fr` and `/ar`, plus switch back to Nightline
   to confirm clean revert. Leave the site on Nightline unless told otherwise.
