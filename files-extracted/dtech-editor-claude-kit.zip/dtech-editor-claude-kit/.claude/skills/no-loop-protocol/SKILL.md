---
name: no-loop-protocol
description: >
  Use whenever you are about to make a code or content change, or when a fix did
  not work. Enforces one atomic change per loop, a git checkpoint before each
  change, revert-don't-stack on failure, and a hard two-strike stop so the project
  never loops on the same problem again.
---

# no-loop-protocol — how we stop spinning

The enemy is the loop: try a fix, can't tell if it worked, try another on top,
context fills with dead ends, days vanish. These rules make that impossible.

## 1. One atomic change per loop
A "change" is the smallest thing that can be independently verified live.
"Fix the editor" is not atomic. "Make the section background-colour control
persist to the published store" is atomic. If you can't describe the change in one
sentence and verify it with one screenshot, it's too big — split it.

## 2. Checkpoint before you touch anything
```
git add -A && git commit -m "checkpoint: before <change>"   # or git stash
```
This is the escape hatch. Without it, a bad change contaminates the next.

## 3. Read fresh before editing
Re-open the target file from disk first. The sandbox mount serves stale/truncated
large files. Editing from memory of a stale file is the #1 source of phantom bugs.

## 4. Verify (see `verify-live`). Then branch:
- **PASS** → commit with a real message. Move to the next atomic change.
- **FAIL** → `git revert`/reset to the checkpoint. **Do NOT add a second fix on
  top of an unverified first.** Re-diagnose from the clean state.

## 5. The two-strike rule (the loop-killer)
If the **same** problem fails verification **twice**, STOP. Do not attempt a third
blind fix. Instead produce a short escalation for the human:
```
STUCK: <problem, one line>
TRIED: 1) <fix> → failed because <observed>
       2) <fix> → failed because <observed>
HYPOTHESES: <2–3 specific, testable guesses>
NEED FROM YOU: <the one decision/credential/fact that unblocks me>
```
Ghani prefers options-once-then-execute. Give him the real fork, not another loop.

## 6. Never let the build lie to you
Only the real `npm run build` (Windows) counts. A green sandbox typecheck means
nothing; a red one is often a false stale-file error. When they disagree, the real
build wins, every time.

## 7. Keep context clean
After a verified change, summarize and drop the intermediate noise. A crowded
context degrades judgment and restarts the looping. Delegate heavy reads to the
`explorer-analyst` subagent so the main thread stays sharp.
