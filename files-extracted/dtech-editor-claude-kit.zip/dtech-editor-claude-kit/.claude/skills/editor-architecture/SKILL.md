---
name: editor-architecture
description: >
  Use before changing anything in the web editor, the on-page edit engine, the
  content store, or the publish flow. Explains how the editor and the live site
  are wired together (iframe canvas, postMessage bridge, draft/published store,
  server actions) so changes preserve the editor↔live link instead of severing it.
---

# editor-architecture — how the link actually works

The whole product promise is "edits in the editor appear on the real site." That
promise lives in this wiring. Understand it before you touch it, or you'll break
the link and not know why.

## The two layers, one engine
1. **Inline editing of the real pages** — every tagged text/link/image and the six
   real homepage sections (Hero, Catégories, Catalogue, Marques, À propos,
   Contact) are editable in place.
2. **Block builder** — new "custom sections" from a 29-template library, filled
   with 23 component types, drag-and-drop arranged.

## The data flow (memorize this path)
```
Studio shell (WebEditor.tsx → LiveEditor)
   │  dark Figma-style chrome: top bar, layers, inspector, ⌘K
   ▼
iframe canvas  =  the REAL site at  /<locale>?edit=1
   │  direct-manipulation editing happens here
   ▼  postMessage bridge  (source:'dtech-editor' ↔ 'dtech-site')
on-page engine  (src/components/site-edit/edit-context.tsx)
   │  EditProvider, Editable, EditableLink, EditableImage,
   │  SectionList, block renderer + builder chrome
   ▼  server actions (src/server/content-actions.ts)
content store: site_pages row keyed  content:<pageKey>
   EditData = { overrides, styles, sections{order,hidden},
                sectionBg, sectionStyles, customSections[], theme }
   with SEPARATE draft + published copies
```

## Server actions — what each does
- `saveContentDraft` — writes the **draft** copy. (Editing state.)
- `publishContent` — copies draft → **published**, revalidates `/fr` and `/ar`.
- `resetContent` — clears draft + published back to original.
- `setContentTheme` — stores the active theme on the page content (see `theme-system`).

## The rule that keeps the link intact
A change only reaches visitors when it lands in the **published** copy AND the
route is revalidated. The classic failure (and the theme bug that was already
fixed once) is **writing to a store the live site never reads**. Before shipping
any editor feature, trace the value end to end:

> control in Inspector → postMessage → engine state → `saveContentDraft` →
> `publishContent` → `editor-page-data.ts` reads published → live route renders it.

If any link in that chain is missing, the editor will *look* like it works while
the real site never changes. That exact gap is what burned weeks. The
`verify-live` skill catches it; this skill explains where to look when it fails.

## Things to respect
- Bulk add re-renders the whole homepage iframe per change → can briefly freeze.
  Add one at a time; if you build a bulk path, debounce/batch the re-render.
- Top nav labels are global chrome, outside per-page edit scope (known gap).
- A duplicated section copies structure, not edited content (known behavior).
- The legacy block-editor / PageDoc path + unused `setDocTheme` still coexist —
  don't accidentally wire new work into the dead path.

## Key files (authoritative)
- `WebEditor.tsx` · `edit-context.tsx` · `section-presets.ts`
- `content-actions.ts` · `editor-page-data.ts`
- `site-themes.css` · `site-theme.tsx` · `themes.ts`
