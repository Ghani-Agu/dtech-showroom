# Hooks (optional but recommended) — make the verify gate deterministic

Skills and agent prompts *guide* behavior. **Hooks enforce it deterministically.**
The 2026 pattern that stops looping is the trinity: *skill teaches the how, hook
enforces the rule, subagent isolates the work.* The one rule worth hard-enforcing
here is: **don't let a turn end claiming "done" without proof of a live screenshot.**

This is optional — the skills + master prompt already push hard on the gate. Add
the hook if you want it to be impossible to skip.

## Sample `.claude/settings.json` (adapt paths to your setup)

```jsonc
{
  "hooks": {
    // Runs when a subagent (e.g. builder/verifier) finishes. Block the result
    // from folding back in unless verification proof exists.
    "SubagentStop": [
      {
        "matcher": "*",
        "hooks": [
          { "type": "command", "command": "node .claude/hooks/check-verified.js" }
        ]
      }
    ]
  }
}
```

## Sample `check-verified.js` (stub — make it match how your verifier writes proof)

```js
// Exit non-zero to BLOCK the stop and tell the agent why.
// Simplest contract: the verifier writes .claude/.last-verification with a line
// "VERDICT: DONE" + screenshot paths when (and only when) it saw the change live.
const fs = require("fs");
const path = ".claude/.last-verification";
try {
  const txt = fs.readFileSync(path, "utf8");
  const ok = /VERDICT:\s*DONE/.test(txt) && /SCREENSHOTS:\s*\S+/.test(txt);
  if (!ok) {
    console.error("BLOCKED: no live verification on record. Run verify-live " +
      "(build → login → publish → load public /fr and /ar fresh → screenshot) " +
      "before claiming done.");
    process.exit(2);
  }
  process.exit(0);
} catch {
  console.error("BLOCKED: .last-verification missing. The change was not verified live.");
  process.exit(2);
}
```

Then have the **verifier** write `.claude/.last-verification` as its final step,
and **clear it** at the start of each new change so a stale pass can't be reused.

> If your Claude Code version's hook schema differs, run `/agents` and the hooks
> docs to confirm the current `SubagentStop` shape, then adapt. Skip this entirely
> and you still get most of the benefit from the skills + prompt.
